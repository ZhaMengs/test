# /zhadev/main.py

import uvicorn
from fastapi import FastAPI
from contextlib import asynccontextmanager

# Import dengan tambahan version info
try:
    from src.zhadev.app.web.app import web_router
    from src.zhadev.app.api.v1.router import api_v1_router
    from src.zhadev.app.core.config import settings
    from src.zhadev.version import get_version_banner, get_version_info, __version__ as version
    print("✅ Semua import berhasil!")
except ImportError as e:
    print(f"❌ Import error: {e}")
    # Fallback
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))
    
    from zhadev.app.web.app import web_router
    from zhadev.app.api.v1.router import api_v1_router
    from zhadev.app.core.config import settings
    from zhadev.version import __version__ as version
    # Fallback functions
    def get_version_banner(): return f"🚀 ZhaDev API v{version}"
    def get_version_info(): return {"version": version}

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup dengan banner yang lebih keren
    print(get_version_banner())
    print(f"📡 Starting {settings.APP_NAME}...")
    yield
    # Shutdown
    print(f"🛑 Shutting down {settings.APP_NAME}...")

app = FastAPI(
    title=settings.APP_NAME,
    version=version,
    description="RESTful API multifungsi dan Antarmuka Web Interaktif",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Include routers (tetap sama)
app.include_router(web_router)
app.include_router(api_v1_router, prefix="/api/v1")

@app.get("/")
async def root():
    version_info = get_version_info()
    return {
        "message": f"Selamat datang di {settings.APP_NAME}",
        "version": version,
        "release": version_info.get("release_tag", "stable"),
        "status": "online",
        "docs": "/docs",
        "api_v1": "/api/v1",
        "author": version_info.get("author", "ZhaDev")
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": settings.APP_NAME}

@app.get("/api")
async def api_info():
    version_info = get_version_info()
    return {
        "message": "ZhaDev RESTful API",
        "version": version,
        "stage": version_info.get("release_tag", "stable"),
        "endpoints": {
            "v1": "/api/v1",
            "docs": "/docs", 
            "web_interface": "/"
        }
    }

# Tambahkan endpoint version info
@app.get("/version")
async def version_endpoint():
    """Endpoint untuk mendapatkan info versi lengkap."""
    return get_version_info()

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )