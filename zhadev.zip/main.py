# main.py

import uvicorn
from fastapi import FastAPI
from contextlib import asynccontextmanager
from src.zhadev.app.web.app import web_router
from src.zhadev.core.config import settings
from src.zhadev.version import version

@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"Memulai {settings.APP_NAME} v{version}...")
    yield
    print("Aplikasi sedang ditutup.")

app = FastAPI(
    title=settings.APP_NAME,
    version=version,
    description="RESTful API multifungsi dan Antarmuka Web Interaktif",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Include web routes
app.include_router(web_router)

@app.get("/")
async def root():
    return {
        "message": f"Selamat datang di {settings.APP_NAME}",
        "version": version,
        "status": "online",
        "docs": "/docs"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "service": settings.APP_NAME}

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )