# zhadev/src/zhadev/cli/commands.py

import typer
import asyncio
from rich.console import Console

from .utils import display_results
from ...crawlers import CrawlerError
# Impor semua kelas crawler yang telah dibuat
from ...crawlers.platforms.china.douyin import DouyinCrawler
from ...crawlers.platforms.china.bilibili import BilibiliCrawler
from ...crawlers.platforms.china.xiaohongshu import XiaohongshuCrawler
from ...crawlers.platforms.china.weibo import WeiboCrawler
from ...crawlers.platforms.global_ import * # Impor semua dari global_


console = Console()
app = typer.Typer(help="ZhaDev Crawler - Alat CLI untuk mengambil data dari berbagai platform.")

# Mapping domain ke kelas crawler yang sesuai
CRAWLER_MAP = {
    "douyin.com": DouyinCrawler,
    "bilibili.com": BilibiliCrawler,
    "bilibili.tv": BstationCrawler,
    "xiaohongshu.com": XiaohongshuCrawler,
    "weibo.com": WeiboCrawler,
    "m.weibo.cn": WeiboCrawler,
    "capcut.com": CapcutCrawler,
    "dailymotion.com": DailymotionCrawler,
    "facebook.com": FacebookCrawler,
    "drive.google.com": GDriveCrawler,
    "github.com": GitHubCrawler,
    "instagram.com": InstagramCrawler,
    "mediafire.com": MediafireCrawler,
    "pinterest.com": PinterestCrawler,
    "pixeldrain.com": PixeldrainCrawler,
    "snackvideo.com": SnackVideoCrawler,
    "spotify.com": SpotifyCrawler,
    "terabox.com": TeraboxCrawler,
    "threads.net": ThreadsCrawler,
    "tiktok.com": TikTokCrawler,
    "youtube.com": YouTubeCrawler,
    "youtu.be": YouTubeCrawler,
    "donghub.vip": DonghubCrawler,
}

def _get_crawler_for_url(url: str):
    """Mendeteksi crawler yang tepat berdasarkan domain URL."""
    for domain, crawler_class in CRAWLER_MAP.items():
        if domain in url:
            return crawler_class()
    return None

async def _run_info(url: str):
    """Logika asinkron untuk menjalankan perintah info."""
    crawler = _get_crawler_for_url(url)
    if not crawler:
        console.print(f"[bold red]Error:[/bold red] Tidak ada crawler yang mendukung URL: {url}")
        raise typer.Exit(code=1)

    try:
        with console.status(f"[bold green]Mengambil data dari {url}...[/bold green]", spinner="dots"):
            # Setiap crawler memiliki method utama yang berbeda, perlu dispatcher lagi
            if isinstance(crawler, (DouyinCrawler, BilibiliCrawler, TikTokCrawler)):
                data = await crawler.get_video_data(url)
            elif isinstance(crawler, WeiboCrawler):
                data = await crawler.get_post_data(url)
            # ... (tambahkan dispatcher untuk setiap crawler)
            else:
                 console.print(f"[bold yellow]Peringatan:[/bold yellow] Method utama untuk {crawler.__class__.__name__} belum ditentukan di CLI.")
                 raise typer.Exit(code=1)

        display_results(data)

    except CrawlerError as e:
        console.print(f"[bold red]Error Crawler:[/bold red] {e}")
        raise typer.Exit(code=1)
    finally:
        if crawler:
            await crawler.close()

@app.command(help="Mengambil informasi detail dari sebuah URL (contoh: video, postingan, repo).")
def info(url: str = typer.Argument(..., help="URL lengkap dari konten yang ingin diambil.")):
    """Wrapper sinkron untuk menjalankan logika info."""
    asyncio.run(_run_info(url))

@app.command(help="[WIP] Mencari konten di platform yang didukung.")
def search(query: str = typer.Argument(..., help="Kata kunci pencarian.")):
    console.print("[yellow]Fitur pencarian sedang dalam pengembangan.[/yellow]")

@app.command(help="[WIP] Mengunduh media dari URL yang didukung.")
def download(url: str = typer.Argument(..., help="URL media yang ingin diunduh.")):
    console.print("[yellow]Fitur unduhan sedang dalam pengembangan.[/yellow]")