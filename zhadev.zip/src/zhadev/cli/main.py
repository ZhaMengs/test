# zhadev/src/zhadev/cli/main.py

import typer
from . import commands
from .. import __version__

# Inisialisasi aplikasi Typer utama
app = typer.Typer(
    name="zhadev-cli",
    help="Aplikasi CLI komprehensif untuk ZhaDev API & Crawlers.",
    no_args_is_help=True
)

def version_callback(value: bool):
    """Callback untuk menampilkan versi aplikasi."""
    if value:
        typer.echo(f"ZhaDev CLI Versi: {__version__}")
        raise typer.Exit()

@app.callback()
def main(
    version: bool = typer.Option(None, "--version", "-v", callback=version_callback, is_eager=True, help="Tampilkan versi aplikasi dan keluar.")
):
    """
    ZhaDev CLI Main App
    """
    pass

# Tambahkan sub-perintah dari file commands.py
app.add_typer(commands.app, name="crawler", help="Akses fungsionalitas crawler.")

# Anda bisa menambahkan sub-perintah lain di sini
# Contoh: app.add_typer(api_commands.app, name="api", help="Kelola ZhaDev RESTful API.")

if __name__ == "__main__":
    app()