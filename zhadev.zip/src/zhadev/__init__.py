# zhadev/src/zhadev/__init__.py

from .version import __version__, __author__

# File ini mengubah direktori 'zhadev' menjadi sebuah Python package.