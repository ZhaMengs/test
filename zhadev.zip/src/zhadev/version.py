# zhadev/src/zhadev/version.py

# Mendefinisikan versi sebagai tuple agar mudah di-increment secara programatik
VERSION = (1, 0, 0, "alpha")

def get_version_string():
    """Mengembalikan versi dalam format string yang umum."""
    if isinstance(VERSION[-1], str):
        return ".".join(map(str, VERSION[:-1])) + f"-{VERSION[-1]}"
    return ".".join(map(str, VERSION))

# __version__ adalah standar yang dikenali oleh banyak tool packaging.
__version__ = get_version_string()
__author__ = "ZhaDev"
__email__ = "youremail@example.com"