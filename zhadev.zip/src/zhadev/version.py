# zhadev/src/zhadev/version.py

"""
Version management for ZhaDev API Platform.
"""

import datetime
from typing import Tuple, Union

# Version tuple: (MAJOR, MINOR, PATCH, RELEASE_TAG)
VERSION: Tuple[Union[int, str], ...] = (1, 0, 0, "alpha")

# Project metadata
__author__ = "ZhaDev Team"
__email__ = "support@zhadev.my.id"
__website__ = "https://zhadev.my.id"
__license__ = "MIT"
__copyright__ = f"Copyright © 2024-{datetime.datetime.now().year} ZhaDev"

def get_version_string() -> str:
    """
    Mengembalikan versi dalam format string yang standar.
    
    Returns:
        str: Version string (e.g., "1.0.0-alpha", "2.1.3")
    """
    if isinstance(VERSION[-1], str):
        return ".".join(map(str, VERSION[:-1])) + f"-{VERSION[-1]}"
    return ".".join(map(str, VERSION))

def get_version_info() -> dict:
    """
    Mengembalikan informasi versi lengkap dalam bentuk dictionary.
    
    Returns:
        dict: Comprehensive version information
    """
    return {
        "version": get_version_string(),
        "major": VERSION[0],
        "minor": VERSION[1],
        "patch": VERSION[2],
        "release_tag": VERSION[3] if len(VERSION) > 3 and isinstance(VERSION[3], str) else "stable",
        "build_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "author": __author__,
        "license": __license__
    }

def get_version_banner() -> str:
    """
    Mengembalikan ASCII banner untuk display version info.
    
    Returns:
        str: ASCII banner text
    """
    version_str = get_version_string()
    banner = f"""
╔══════════════════════════════════════════════════════════════╗
║                   🚀 ZhaDev API Platform                    ║
║                                                              ║
║    Version: {version_str:<15} Build: {datetime.datetime.now().strftime('%Y-%m-%d'):<10} ║
║    Author:  {__author__:<15} License: {__license__:<8}        ║
║    Email:   {__email__:<36} ║
║    Website: {__website__:<36} ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
    return banner

def is_stable() -> bool:
    """
    Mengecek apakah ini versi stable.
    
    Returns:
        bool: True jika versi stable, False jika pre-release
    """
    if len(VERSION) > 3:
        return VERSION[3] in ["stable", "final", "release"]
    return True

def is_development() -> bool:
    """
    Mengecek apakah ini versi development.
    
    Returns:
        bool: True jika versi development/pre-release
    """
    if len(VERSION) > 3:
        return VERSION[3] in ["alpha", "beta", "rc", "dev"]
    return False

# Standard version string
__version__ = get_version_string()

# Export public API
__all__ = [
    '__version__',
    '__author__', 
    '__email__',
    '__website__',
    '__license__',
    '__copyright__',
    'get_version_string',
    'get_version_info',
    'get_version_banner',
    'is_stable',
    'is_development',
    'VERSION'
]