# /zhadev/app/web/routes/__init__.py

from .about import app as about
from .ai import app as ai
from .downloader import app as downloader
from .random import app as random
from .stalker import app as stalker
from .documentation import app as documentation
from .easter_egg import app as easter_egg
from .tools import app as tools
from .search import app as search
from .parser import app as parser
from .shortcuts import app as shortcuts

__all__ = [
    'about',
    'ai', 
    'downloader',
    'random',
    'stalker',
    'documentation',
    'easter_egg',
    'tools',
    'search',
    'parser',
    'shortcuts',
]