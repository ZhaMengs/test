# /zhadev/app/web/routes/search.py

import httpx
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env
from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/search"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman Search."""
    set_env(title="ZhaDev Tools - Universal Search")
    render_navbar(active_page='search')
    put_html("<h1 align='center'><strong>Universal Search</strong></h1>")

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            data = await input_group("Cari Konten", [
                select("Pilih Platform", name="platform", options=[
                    "youtube", "tiktok", "donghub", "pinterest", "bilibili"
                ]),
                input("Masukkan Kata Kunci", name="q", type="text", required=True),
            ])
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow')
            put_text(f"Mencari '{data['q']}' di {data['platform']}...", align='center')

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{data['platform']}/",
                    params={"q": data['q'], "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                results = response.json()['data']

            with use_scope("result_scope", clear=True):
                if not results:
                    put_warning(f"Tidak ada hasil yang ditemukan untuk '{data['q']}'.")
                else:
                    put_success(f"Menampilkan {len(results)} hasil teratas:")
                    table_data = []
                    for item in results:
                        # Buat baris tabel dari data hasil (disesuaikan untuk berbagai platform)
                        title = item.get('title', 'N/A')
                        # Hapus tag HTML dari judul Bilibili
                        if 'bilibili' in data['platform']:
                            title = BeautifulSoup(title, "html.parser").get_text()

                        table_data.append([
                            put_image(item.get('cover_url', ''), width='100px') if item.get('cover_url') else "No Image",
                            put_markdown(f"**[{title}]({item.get('url')})**\n\nAuthor: {item.get('author', 'N/A')}"),
                        ])
                    put_table(table_data, header=["Cover", "Detail"])

        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
                put_error("Terjadi Kesalahan", str(error_detail))