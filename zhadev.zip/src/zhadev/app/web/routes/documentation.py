# /zhadev/app/web/routes/documentation.py

from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

async def app():
    """Halaman dokumentasi interaktif untuk API."""
    set_env(title="ZhaDev Tools - Documentation")
    render_navbar(active_page='documentation')

    put_html("<h1>API Documentation</h1>")
    put_markdown("""
    Selamat datang di dokumentasi ZhaDev API. Semua endpoint di bawah `/api/v1/` memerlukan autentikasi menggunakan `apikey` sebagai parameter query.

    **Base URL:** `http://localhost:8000/api/v1`
    **Autentikasi:** Tambahkan `?apikey=YOUR_API_KEY` di akhir setiap permintaan.
    
    ### Kunci API Gratis yang Tersedia:
    - `zhadev_restapi`
    - `zhadev_freekey`
    - `zhadev_freeapi`
    
    Gunakan generator di bawah ini untuk membuat contoh URL permintaan.
    """)
    put_scope("generator_scope")
    
    while True:
        with use_scope("generator_scope", clear=True):
            put_html("<hr><h3>URL Generator</h3>")
            data = await input_group("Buat Contoh Permintaan", [
                select("Pilih Modul", name="module", options=["downloader", "stalker", "search", "ai"]),
                input("Masukkan Kunci API Anda", name="apikey", value="zhadev_restapi"),
                input("Masukkan Parameter Utama", name="param", help_text="URL untuk downloader/stalker, Query untuk search, Prompt untuk AI"),
            ])
        
        # Logika sederhana untuk menentukan endpoint
        endpoint_map = {
            "downloader": "tiktok", # Contoh default
            "stalker": "instagram", # Contoh default
            "search": "youtube", # Contoh default
            "ai": "gemini", # Contoh default
        }
        param_map = {
            "downloader": "url",
            "stalker": "url",
            "search": "q",
            "ai": "prompt",
        }
        
        module = data['module']
        endpoint = endpoint_map[module]
        param_name = param_map[module]
        
        if module == "ai":
            # AI menggunakan POST, tampilkan contoh cURL
            curl_command = f"""
            <p>API AI menggunakan metode POST. Berikut contoh cURL:</p>
            <pre><code>curl -X POST "http://localhost:8000/api/v1/{module}/{endpoint}/?apikey={data['apikey']}" \\
            -H "Content-Type: application/json" \\
            -d '&#123;"{param_name}": "{data['param']}"&#125;'</code></pre>
            """
            put_html(curl_command)
        else:
            # Tampilkan URL GET yang bisa diklik
            url = f"http://localhost:8000/api/v1/{module}/{endpoint}/?{param_name}={data['param']}&apikey={data['apikey']}"
            put_markdown(f"**Generated URL:**")
            put_html(f'<p><a href="{url}" target="_blank">{url}</a></p>')