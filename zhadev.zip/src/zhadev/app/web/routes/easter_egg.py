# /zhadev/app/web/routes/easter_egg.py

import pyfiglet
from pywebio.output import *
from pywebio.session import set_env
from .utils import render_navbar

async def app():
    """Halaman Easter Egg."""
    set_env(title="ZhaDev Tools - ???")
    # Sengaja tidak ada navbar untuk membuatnya tersembunyi
    
    put_html("<h1 align='center'>You Found a Secret!</h1>")
    
    text = "ZhaDev"
    ascii_art = pyfiglet.figlet_format(text, font="slant")
    
    put_code(ascii_art)
    put_markdown("---")
    put_text("Terima kasih telah menjelajahi proyek ini!", align='center')