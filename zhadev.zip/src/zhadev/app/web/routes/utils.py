from pywebio.output import put_html

def render_navbar(active_page: str):
    """Membuat dan menampilkan navbar dengan halaman aktif yang ditandai."""
    nav_items = {
        "Downloader": "downloader",
        "Stalker": "stalker",
        "Search": "search",
        "Tools": "tools",
        "AI Assistant": "ai",
        "Parser": "parser",
        "Random": "random",
        "Documentation": "documentation",
        "About": "about",
    }
    
    styles = """
    <style>
        .navbar { overflow: hidden; background-color: #333; margin-bottom: 20px; }
        .navbar button { float: left; display: block; color: #f2f2f2; text-align: center; padding: 14px 16px; text-decoration: none; font-size: 17px; border: none; background: none; cursor: pointer; }
        .navbar button:hover { background-color: #ddd; color: black; }
        .navbar button.active { background-color: #04AA6D; color: white; }
    </style>
    """
    
    buttons_html = ""
    for display, name in nav_items.items():
        active_class = 'active' if name == active_page else ''
        buttons_html += f'<button class="navbar-btn {active_class}" onclick="WebIO.go_app(\'{name}\', false)">{display}</button>'
        
    put_html(styles + f'<div class="navbar">{buttons_html}</div>')