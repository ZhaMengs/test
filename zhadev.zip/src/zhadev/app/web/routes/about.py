# /zhadev/app/web/routes/about.py

from pywebio.output import *
from pywebio.session import set_env
from .utils import render_navbar
import sys
import os

# Tambahkan path untuk import version
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))

try:
    from src.zhadev.version import get_version_info, __author__, __email__, __website__
    version_info = get_version_info()
except ImportError:
    # Fallback
    from src.zhadev.version import __version__
    version_info = {"version": __version__, "release_tag": "alpha"}
    __author__ = "ZhaDev"
    __email__ = "support@zhadev.my.id" 
    __website__ = "https://zhadev.my.id"

async def app():
    """Halaman "About" untuk aplikasi ZhaDev."""
    set_env(title="ZhaDev Tools - About")
    render_navbar(active_page='about')

    put_html("<h1><img src='https://zhadev.my.id/wp-content/uploads/2024/07/Zha-1-1.png' width='50px' style='vertical-align: middle;'> About ZhaDev Project</h1>")
    
    # Tampilkan info versi yang lebih detail
    put_table([
        ["Versi", f"`{version_info['version']}`"],
        ["Status", f"{version_info.get('release_tag', 'stable').upper()}"],
        ["Pembuat", __author__],
        ["Email", __email__],
        ["Website", put_link(__website__, __website__, new_window=True)],
        ["Lisensi", version_info.get('license', 'MIT')],
    ])
    
    put_markdown("""
    Proyek ini adalah demonstrasi pembuatan RESTful API dan antarmuka web yang komprehensif menggunakan Python.
    
    ## 🛠️ Teknologi yang Digunakan
    - **Backend API**: **FastAPI**
    - **Antarmuka Web**: **PyWebIO** 
    - **HTTP Client**: **HTTPX**
    - **AI & Tools**: Berbagai API pihak ketiga (Replicate, OpenAI, dll.)
    
    Proyek ini dirancang untuk menjadi modular, kuat, dan mudah diperluas.
    """)

    put_table(
        header=["Komponen", "Deskripsi"],
        tdata=[
            ["`/crawlers`", "Lapisan pengambilan data, berisi logika untuk setiap platform."],
            ["`/app/api`", "Lapisan RESTful API yang mengekspos fungsionalitas ke publik."],
            ["`/app/web`", "Lapisan antarmuka pengguna interaktif yang Anda gunakan sekarang."],
        ]
    )
    
    # Tambahkan fitur yang tersedia
    put_markdown("""
    ## ✨ Fitur Utama
    - ✅ **Downloader** - Download konten dari 20+ platform
    - ✅ **AI Tools** - Akses berbagai model AI (DeepSeek, Gemini, dll.)
    - ✅ **Stalker** - Analisis profil sosial media  
    - ✅ **Random Content** - Kutipan inspiratif anime & donghua
    - ✅ **Search Tools** - Pencarian multi-platform
    - ✅ **Utility Tools** - OCR, enhancement, dll.
    - ✅ **iOS Shortcuts** - Integrasi dengan Apple Shortcuts
    """)