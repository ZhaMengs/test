# /zhadev/app/web/routes/stalker.py

# Pola implementasinya akan sangat mirip dengan downloader.py
# karena keduanya menerima input URL tunggal.

import httpx
from urllib.parse import urlparse
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env

from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/stalker"
INTERNAL_API_KEY = "zhadev_restapi"

# Mapping domain ke platform stalker
PLATFORM_MAP = {
    "douyin.com": "douyin", "tiktok.com": "tiktok",
    "bilibili.com": "bilibili", "bilibili.tv": "bstation",
    "instagram.com": "instagram", "twitter.com": "twitter", "x.com": "twitter",
    # ... tambahkan domain lain
}

async def app():
    """Aplikasi PyWebIO untuk halaman Stalker."""
    set_env(title="ZhaDev Tools - Profile Stalker")
    render_navbar(active_page='stalker')
    put_html("<h1 align='center'><strong>Profile Stalker</strong></h1>")
    
    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            url = await input("Masukkan URL Profil", type="text", required=True,
                              placeholder="Contoh: https://www.instagram.com/instagram")
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow')
            put_text("Menganalisis profil...", align='center')

        try:
            domain = urlparse(url).hostname.replace("www.", "")
            platform = None
            for key, value in PLATFORM_MAP.items():
                if key in domain:
                    platform = value
                    break
            
            if not platform:
                raise ValueError(f"Platform untuk domain '{domain}' tidak didukung.")

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result = response.json()

            with use_scope("result_scope", clear=True):
                put_success("Profil Berhasil Ditemukan!")
                put_code(json.dumps(result['data'], indent=2), language='json')

        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
                put_error("Terjadi Kesalahan", str(error_detail))