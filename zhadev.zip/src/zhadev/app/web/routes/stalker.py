# /zhadev/app/web/routes/stalker.py

import httpx
import json
from urllib.parse import urlparse
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/stalker"
INTERNAL_API_KEY = "zhadev_restapi"

# Mapping domain ke platform stalker
PLATFORM_MAP = {
    "douyin.com": "douyin", 
    "tiktok.com": "tiktok", "vm.tiktok.com": "tiktok",
    "bilibili.com": "bilibili", "bilibili.tv": "bstation", "b23.tv": "bilibili",
    "instagram.com": "instagram", 
    "twitter.com": "twitter", "x.com": "twitter",
    "youtube.com": "youtube", "youtu.be": "youtube",
    "facebook.com": "facebook",
    "weibo.com": "weibo",
    "xiaohongshu.com": "xiaohongshu",
    "capcut.com": "capcut",
    # donghub dihapus sesuai permintaan
}

async def app():
    """Aplikasi PyWebIO untuk halaman Stalker."""
    set_env(title="ZhaDev Tools - Profile Stalker")
    render_navbar(active_page='stalker')
    put_html("<h1 align='center'><strong>👤 Profile Stalker</strong></h1>")
    
    put_markdown("""
    **Analisis profil dari berbagai platform sosial media:**
    
    ### Platform yang Didukung:
    - 📷 **Instagram** - Profile & posts analysis
    - 🎵 **TikTok** - User profile & videos
    - 🇨🇳 **Douyin** - Chinese TikTok profiles
    - 🎬 **YouTube** - Channel analytics
    - 🐦 **Twitter/X** - User profile & tweets
    - 📘 **Facebook** - Public profiles
    - 🇨🇳 **Weibo** - Chinese microblogging
    - 📕 **Xiaohongshu** - Little Red Book
    - ✂️ **CapCut** - Video editor profiles
    - 🇨🇳 **Bilibili** - Chinese video platform
    - 📺 **BStation** - Bilibili international
    """)

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            url = await input(
                "🔗 Masukkan URL Profil", 
                type="text", 
                required=True,
                placeholder="Contoh: https://www.instagram.com/instagram\nhttps://www.tiktok.com/@username\nhttps://www.youtube.com/@channel"
            )
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow', color='primary')
            put_html("<center>🔍 Menganalisis profil...</center>")

        try:
            parsed_url = urlparse(url)
            domain = parsed_url.hostname.replace("www.", "") if parsed_url.hostname else ""
            
            if not domain:
                raise ValueError("URL tidak valid")
            
            platform = None
            for key, value in PLATFORM_MAP.items():
                if key in domain:
                    platform = value
                    break
            
            if not platform:
                available_platforms = ", ".join(sorted(set(PLATFORM_MAP.values())))
                raise ValueError(f"❌ Platform untuk domain '{domain}' tidak didukung. Platform yang tersedia: {available_platforms}")

            # Tampilkan info platform yang terdeteksi
            with use_scope("result_scope", clear=True):
                put_info(f"🔍 Platform terdeteksi: {platform.upper()}")
                put_loading(shape='grow', color='primary')

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result = response.json()

            with use_scope("result_scope", clear=True):
                data = result.get('data', {})
                
                put_success(f"✅ Profil {platform.upper()} Berhasil Ditemukan!")
                
                # Tampilkan informasi profil yang user-friendly
                if data:
                    # Header profil
                    if data.get('avatar') or data.get('profile_pic'):
                        avatar_url = data.get('avatar') or data.get('profile_pic')
                        put_image(avatar_url, width='100px', height='100px')
                    
                    put_html(f"<h3>👤 {data.get('username', data.get('name', 'N/A'))}</h3>")
                    
                    # Informasi dasar
                    profile_info = []
                    if data.get('followers'):
                        profile_info.append(f"**Followers:** {data.get('followers')}")
                    if data.get('following'):
                        profile_info.append(f"**Following:** {data.get('following')}")
                    if data.get('posts_count'):
                        profile_info.append(f"**Posts:** {data.get('posts_count')}")
                    if data.get('bio') or data.get('description'):
                        profile_info.append(f"**Bio:** {data.get('bio', data.get('description', 'N/A'))}")
                    
                    if profile_info:
                        put_markdown("\n".join(profile_info))
                    
                    # Tampilkan posts/contents jika ada
                    if data.get('posts') or data.get('videos'):
                        posts = data.get('posts', data.get('videos', []))
                        if posts:
                            put_html("<h4>📱 Recent Posts:</h4>")
                            for i, post in enumerate(posts[:5]):  # Tampilkan 5 post terbaru
                                put_markdown(f"**{i+1}. {post.get('title', post.get('description', 'Post'))}**")
                                if post.get('thumbnail'):
                                    put_image(post.get('thumbnail'), width='200px')
                                put_markdown("---")
                    
                    # Juga tampilkan JSON raw untuk debugging
                    put_collapse("📊 Raw JSON Data", 
                                put_code(json.dumps(data, indent=2, ensure_ascii=False), language='json'))
                
                else:
                    put_warning("⚠️ Data profil ditemukan tetapi kosong")
                
                # Tombol untuk stalk profile lain
                put_buttons(['🔍 Stalk Profile Lain'], onclick=lambda: run_js('location.reload()'))

        except httpx.HTTPStatusError as e:
            with use_scope("result_scope", clear=True):
                put_error(f"❌ HTTP Error {e.response.status_code}", 
                         f"Gagal mengambil profil: {e.response.text}")
                put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))
                
        except httpx.RequestError as e:
            with use_scope("result_scope", clear=True):
                put_error("🌐 Connection Error", 
                         f"Tidak dapat terhubung ke server: {str(e)}")
                put_html("<p>Pastikan server API sedang berjalan di localhost:8000</p>")
                
        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = ""
                if hasattr(e, 'response') and e.response:
                    try:
                        error_detail = e.response.json().get('detail', str(e))
                    except:
                        error_detail = str(e)
                else:
                    error_detail = str(e)
                    
                put_error("💥 Terjadi Kesalahan", error_detail)
                put_buttons(['🔄 Coba Lagi'], onclick=lambda: run_js('location.reload()'))