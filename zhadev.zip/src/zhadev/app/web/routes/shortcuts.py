import httpx
import json
from urllib.parse import urlparse, parse_qs
from pywebio.output import *
from pywebio.session import set_env, eval_js, run_js

from ....crawlers.exceptions import ContentNotFoundError

PLATFORM_MAP = {
    "douyin.com": "douyin", "tiktok.com": "tiktok", "vm.tiktok.com": "tiktok",
    "bilibili.com": "bilibili", "bilibili.tv": "bstation", "b23.tv": "bilibili",
    "instagram.com": "instagram", "threads.net": "threads",
    "youtube.com": "youtube", "youtu.be": "youtube", "twitter.com": "twitter", "x.com": "twitter",
}

API_BASE_URL = "http://localhost:8000/api/v1/downloader"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """
    Backend non-visual untuk iOS Shortcuts.
    Menerima parameter dari URL, memprosesnya, dan mengembalikan hasil ke aplikasi Pintasan.
    """
    set_env(title="ZhaDev Shortcuts Backend")
    put_html("<h1>Processing Shortcut...</h1>")
    put_loading(shape='grow')

    try:
        # 1. Dapatkan parameter dari URL query
        query_string = await eval_js("window.location.search")
        params = parse_qs(query_string.lstrip('?'))
        
        action = params.get('action', [None])[0]
        url = params.get('url', [None])[0]
        callback_shortcut = params.get('callback', ['DefaultCallback'])[0]

        if not action or not url:
            raise ValueError("Parameter 'action' dan 'url' wajib ada.")

        # 2. Lakukan aksi yang diminta (saat ini hanya 'download')
        if action == 'download':
            # Temukan platform yang sesuai
            domain = urlparse(url).hostname.replace("www.", "")
            platform = next((plat for dom, plat in PLATFORM_MAP.items() if dom in domain), None)
            
            if not platform:
                raise ContentNotFoundError(f"Platform untuk URL '{url}' tidak didukung.")

            # Panggil API downloader
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result_data = response.json()['data']
            
            # 3. Ekstrak link unduhan utama
            download_link = ""
            if platform in ["douyin", "tiktok"]:
                download_link = result_data.get('video', {}).get('url_no_watermark', '')
            elif platform == "instagram":
                download_link = result_data.get('media_items', [{}])[0].get('video_url') or result_data.get('media_items', [{}])[0].get('display_url')
            # ... tambahkan logika ekstraksi untuk platform lain

            if not download_link:
                raise ValueError("Tidak dapat menemukan link unduhan utama dari respons API.")

            # 4. Kirim kembali hasil ke iOS Shortcuts
            # Ini akan memanggil shortcut lain di iOS bernama `callback_shortcut`
            # dan mengirim `download_link` sebagai inputnya.
            put_success("Proses selesai. Mengembalikan hasil ke aplikasi Pintasan.")
            run_js(f'window.location.href = "shortcuts://run-shortcut?name={callback_shortcut}&input=text&text={download_link}"')

        else:
            raise ValueError(f"Aksi '{action}' tidak didukung.")

    except Exception as e:
        error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
        put_error("Gagal memproses pintasan", str(error_detail))
        # Opsi: Kirim pesan error kembali ke Shortcuts
        # run_js(f'window.location.href = "shortcuts://run-shortcut?name={callback_shortcut}&input=text&text=ERROR:{error_detail}"')