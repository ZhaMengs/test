import httpx
import json
from urllib.parse import urlparse
from pywebio.output import *
from pywebio.input import *
from pywebio.session import set_env

from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1"
INTERNAL_API_KEY = "zhadev_restapi"

# Mapping domain ke modul API (downloader atau stalker)
PLATFORM_MAP = {
    "douyin.com": ("downloader", "douyin"), "tiktok.com": ("downloader", "tiktok"),
    "bilibili.com": ("downloader", "bilibili"), "bilibili.tv": ("downloader", "bstation"),
    "instagram.com": ("downloader", "instagram"), "twitter.com": ("downloader", "twitter"),
    "youtube.com": ("downloader", "youtube"), "mediafire.com": ("downloader", "mediafire"),
    # Tambahkan mapping untuk stalker jika format URL-nya jelas
    # "instagram.com/username": ("stalker", "instagram"), # Contoh
}

async def app():
    """Aplikasi PyWebIO untuk halaman Parser."""
    set_env(title="ZhaDev Tools - Raw API Parser")
    render_navbar(active_page='parser')
    put_html("<h1 align='center'><strong>Raw API Parser</strong></h1>")
    put_markdown("Alat ini memanggil endpoint API yang relevan dan menampilkan respons JSON mentah. Berguna untuk *debugging*.")

    put_scope("form_scope")
    put_scope("result_scope")

    while True:
        with use_scope("form_scope", clear=True):
            url = await input("Masukkan URL Apapun yang Didukung", type="text", required=True)
        
        with use_scope("result_scope", clear=True):
            put_loading(shape='grow')

        try:
            domain = urlparse(url).hostname.replace("www.", "")
            module, platform = None, None
            for key, (mod, plat) in PLATFORM_MAP.items():
                if key in domain:
                    module, platform = mod, plat
                    break
            
            if not platform:
                raise ValueError(f"Platform untuk domain '{domain}' tidak didukung.")

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(
                    f"{API_BASE_URL}/{module}/{platform}/",
                    params={"url": url, "apikey": INTERNAL_API_KEY}
                )
                response.raise_for_status()
                result = response.json()

            with use_scope("result_scope", clear=True):
                put_success("Respons API Berhasil Diterima")
                put_code(json.dumps(result, indent=2), language='json')

        except Exception as e:
            with use_scope("result_scope", clear=True):
                error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
                put_error("Terjadi Kesalahan", str(error_detail))