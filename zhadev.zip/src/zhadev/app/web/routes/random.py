# /zhadev/app/web/routes/random.py

import httpx
from pywebio.output import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/random"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman Random Content."""
    set_env(title="ZhaDev Tools - Random Content")
    render_navbar(active_page='random')
    put_html("<h1 align='center'><strong>Random Content Generator</strong></h1>")
    
    # Ganti pendekatan: langsung panggil fungsi tanpa registrasi
    put_buttons(
        ['Get Random Quote', 'Get Anime Quote', 'Get Donghua Quote'],
        onclick=[
            lambda: fetch_random_content_wrapper('quotes'),
            lambda: fetch_random_content_wrapper('anime-quotes'), 
            lambda: fetch_random_content_wrapper('donghua-quotes'),
        ]
    )
    put_scope("result_scope")

async def fetch_random_content_wrapper(content_type: str):
    """Wrapper untuk memanggil fetch_random_content"""
    await fetch_random_content(content_type)

async def fetch_random_content(content_type: str):
    with use_scope("result_scope", clear=True):
        put_loading(shape='grow')
    
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.get(
                f"{API_BASE_URL}/{content_type}/",
                params={"apikey": INTERNAL_API_KEY}
            )
            response.raise_for_status()
            result = response.json()['data']
        
        with use_scope("result_scope", clear=True):
            if content_type == 'quotes':
                put_html(result['h'])
            elif content_type == 'anime-quotes':
                put_blockquote(result['quote'], f"~ {result['character']}, {result['anime']}")
            elif content_type == 'donghua-quotes':
                put_blockquote(result['quote_text'], f"~ {result['source_novel']}")
    
    except Exception as e:
        with use_scope("result_scope", clear=True):
            error_detail = e.response.json()['detail'] if hasattr(e, 'response') else str(e)
            put_error("Gagal Mengambil Data", str(error_detail))

# Hapus semua baris registrasi