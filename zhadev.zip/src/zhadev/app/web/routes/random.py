# /zhadev/app/web/routes/random.py

import httpx
from pywebio.output import *
from pywebio.session import set_env, run_js
from .utils import render_navbar

API_BASE_URL = "http://localhost:8000/api/v1/random"
INTERNAL_API_KEY = "zhadev_restapi"

async def app():
    """Aplikasi PyWebIO untuk halaman Random Content."""
    set_env(title="ZhaDev Tools - Random Content")
    render_navbar(active_page='random')
    put_html("<h1 align='center'><strong>🎲 Random Content Generator</strong></h1>")
    
    put_markdown("""
    **Temukan kutipan inspiratif secara acak:**
    - 💫 **Random Quotes** - Kutipan motivasi umum
    - 🇯🇵 **Anime Quotes** - Kutipan dari anime populer  
    - 🇨🇳 **Donghua Quotes** - Kutipan dari donghua (animasi China)
    """)
    
    put_buttons(
        ['💫 Random Quote', '🇯🇵 Anime Quote', '🇨🇳 Donghua Quote'],
        onclick=[
            lambda: fetch_random_content_wrapper('quotes'),
            lambda: fetch_random_content_wrapper('anime-quotes'), 
            lambda: fetch_random_content_wrapper('donghua-quotes'),
        ]
    )
    put_scope("result_scope")

async def fetch_random_content_wrapper(content_type: str):
    """Wrapper untuk memanggil fetch_random_content"""
    await fetch_random_content(content_type)

async def fetch_random_content(content_type: str):
    with use_scope("result_scope", clear=True):
        put_loading(shape='grow', color='primary')
        put_html("<center>🔄 Mengambil konten acak...</center>")
    
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.get(
                f"{API_BASE_URL}/{content_type}/",
                params={"apikey": INTERNAL_API_KEY}
            )
            response.raise_for_status()
            result = response.json()['data']
        
        with use_scope("result_scope", clear=True):
            if content_type == 'quotes':
                put_success("💫 Random Quote")
                put_html(f"<div style='font-size: 1.2em; text-align: center; padding: 20px;'>{result['h']}</div>")
                
            elif content_type == 'anime-quotes':
                put_success("🇯🇵 Anime Quote")
                put_html(f"""
                <div style='border-left: 4px solid #4CAF50; padding-left: 15px; margin: 20px 0;'>
                    <p style='font-size: 1.1em; font-style: italic;'>"{result['quote']}"</p>
                    <p style='text-align: right; color: #666;'>~ {result['character']}, <strong>{result['anime']}</strong></p>
                </div>
                """)
                
            elif content_type == 'donghua-quotes':
                put_success("🇨🇳 Donghua Quote") 
                put_html(f"""
                <div style='border-left: 4px solid #FF9800; padding-left: 15px; margin: 20px 0;'>
                    <p style='font-size: 1.1em; font-style: italic;'>"{result['quote_text']}"</p>
                    <p style='text-align: right; color: #666;'>~ <strong>{result['source_novel']}</strong></p>
                </div>
                """)
            
            # Tombol untuk mendapatkan lebih banyak
            put_buttons(
                ['🎲 Lagi!'],
                onclick=[lambda: fetch_random_content_wrapper(content_type)]
            )
    
    except httpx.HTTPStatusError as e:
        with use_scope("result_scope", clear=True):
            put_error(f"❌ HTTP Error {e.response.status_code}", 
                     f"Gagal mengambil data: {e.response.text}")
            put_buttons(['🔄 Coba Lagi'], onclick=lambda: fetch_random_content_wrapper(content_type))
            
    except httpx.RequestError as e:
        with use_scope("result_scope", clear=True):
            put_error("🌐 Connection Error", 
                     f"Tidak dapat terhubung ke server: {str(e)}")
            put_html("<p>Pastikan server API sedang berjalan di localhost:8000</p>")
            
    except Exception as e:
        with use_scope("result_scope", clear=True):
            error_detail = ""
            if hasattr(e, 'response') and e.response:
                try:
                    error_detail = e.response.json().get('detail', str(e))
                except:
                    error_detail = str(e)
            else:
                error_detail = str(e)
                
            put_error("💥 Terjadi Kesalahan", error_detail)
            put_buttons(['🔄 Coba Lagi'], onclick=lambda: fetch_random_content_wrapper(content_type))