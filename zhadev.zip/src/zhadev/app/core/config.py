# zhadev/src/zhadev/core/config.py

from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    """
    Manajemen konfigurasi terpusat untuk seluruh aplikasi.
    Membaca nilai dari environment variables atau file .env secara otomatis.
    """
    # Konfigurasi Aplikasi Dasar
    APP_NAME: str = "ZhaDev RESTful API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # Konfigurasi API Internal Anda
    API_PREFIX: str = "/api/v1"
    
    # --- KUNCI API PIHAK KETIGA (RAHASIA) ---
    # Pastikan nama variabel di sini SAMA PERSIS dengan yang ada di file .env Anda.
    # Pydantic akan otomatis mencocokkannya (case-insensitive).
    DEEPSEEK_API_KEY: Optional[str] = None
    CLAUDE_API_KEY: Optional[str] = None
    CHATGPT_API_KEY: Optional[str] = None
    GEMINI_API_KEY: Optional[str] = None
    BITESHIP_API_KEY: Optional[str] = None
    REPLICATE_API_TOKEN: Optional[str] = None
    OPENWEATHER_API_KEY: Optional[str] = None
    
    # Untuk membaca dari file .env di root project
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding='utf-8', extra='ignore')

# Buat satu instance settings yang akan digunakan di seluruh aplikasi
settings = Settings()