# /zhadev/app/api/v1/router.py

from fastapi import APIRouter, Depends

from .dependencies import rate_limiter # Impor dependency rate limiter kita

# Impor router utama dari setiap modul yang telah kita buat
from .downloader import downloader_router
from .stalker import stalker_router
from .search import search_router
from .tools import tools_router
from .random import random_router
from .ai import ai_router

# Inisialisasi router utama untuk V1
# Dengan menerapkan dependency di sini, semua endpoint di bawahnya
# akan otomatis dilindungi oleh rate limiter dan validasi API key.
api_v1_router = APIRouter(
    dependencies=[Depends(rate_limiter)]
)

# Gabungkan semua router modul ke dalam router V1 utama dengan prefix yang sesuai
api_v1_router.include_router(ai_router, prefix="/ai")
api_v1_router.include_router(downloader_router, prefix="/downloader")
api_v1_router.include_router(random_router, prefix="/random")
api_v1_router.include_router(stalker_router, prefix="/stalker")
api_v1_router.include_router(search_router, prefix="/search")
api_v1_router.include_router(tools_router, prefix="/tools")

@api_v1_router.get("/", tags=["V1 Root"])
async def read_v1_root():
    """Endpoint root untuk V1 untuk memastikan API aktif."""
    return {"message": "Selamat datang di ZhaDev API v1", "status": "aktif"}