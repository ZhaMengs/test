# /zhadev/app/api/v1/tools/url_shortener.py

import time
import string
import random
import sqlite3
from pathlib import Path
from fastapi import APIRouter, Depends, Query, HTTPException, status, Request
from pydantic import BaseModel, HttpUrl

from ..models import StandardResponse, ErrorResponse, validate_api_key

router = APIRouter()

# Setup Database SQLite
DB_PATH = Path("data/url_shortener.db")
DB_PATH.parent.mkdir(exist_ok=True) # Buat direktori `data` jika belum ada
con = sqlite3.connect(DB_PATH, check_same_thread=False)
cur = con.cursor()
cur.execute("""
    CREATE TABLE IF NOT EXISTS urls (
        short_code TEXT PRIMARY KEY,
        long_url TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
""")
con.commit()

def generate_short_code(length: int = 6) -> str:
    """Menghasilkan kode acak unik."""
    chars = string.ascii_letters + string.digits
    while True:
        code = "".join(random.choice(chars) for _ in range(length))
        # Pastikan kode belum ada di database
        if not cur.execute("SELECT short_code FROM urls WHERE short_code = ?", (code,)).fetchone():
            return code

class ShortenerInput(BaseModel):
    url: HttpUrl # Pydantic akan otomatis memvalidasi ini adalah URL yang valid

class ShortenerOutput(BaseModel):
    short_url: str
    long_url: HttpUrl

@router.post(
    "/",
    response_model=StandardResponse[ShortenerOutput],
    summary="Membuat URL pendek baru"
)
async def create_short_url(
    request: ShortenerInput,
    http_request: Request,
    api_key: str = Depends(validate_api_key)
):
    """
    Menerima URL panjang dan mengembalikannya dalam versi pendek.
    """
    start_time = time.time()
    try:
        short_code = generate_short_code()
        long_url = str(request.url) # Konversi Pydantic URL ke string
        
        cur.execute("INSERT INTO urls (short_code, long_url) VALUES (?, ?)", (short_code, long_url))
        con.commit()
        
        # Asumsi domain kustom Anda. Ini perlu disesuaikan.
        # Untuk tujuan API, kita kembalikan URL lengkap.
        # Logika redirect akan ditangani di level root aplikasi.
        short_url_domain = "short.zhadev.my.id" # Ganti sesuai domain Anda
        full_short_url = f"http://{short_url_domain}/{short_code}"

        result = ShortenerOutput(short_url=full_short_url, long_url=long_url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)
        
    except Exception as e:
        con.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal membuat URL pendek: {str(e)}")

# PENTING: Untuk membuat redirect berfungsi, tambahkan kode ini ke file `main.py` Anda.
# from fastapi.responses import RedirectResponse
# from .data import url_shortener_db # Anda perlu membuat file ini untuk mengelola koneksi DB
#
# @app.get("/{short_code}", tags=["URL Redirect"])
# async def redirect_url(short_code: str):
#     long_url = url_shortener_db.get_long_url(short_code)
#     if long_url:
#         return RedirectResponse(url=long_url)
#     raise HTTPException(status_code=404, detail="URL tidak ditemukan")