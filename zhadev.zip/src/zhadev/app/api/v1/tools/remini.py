# /zhadev/app/api/v1/tools/remini.py

import time
import replicate
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class ReminiOutput(BaseModel):
    output_url: str

# Kita gunakan kembali model Real-ESRGAN yang powerful
ESRGAN_MODEL_VERSION = "42fed1c4974146d4d2414e2be2c523779943453178656d654e0428d34b076219"

@router.get(
    "/",
    response_model=StandardResponse[ReminiOutput],
    summary="Meningkatkan resolusi gambar ke kualitas super (ala Remini)"
)
async def remini_style_upscale(
    url: str = Query(..., description="URL ke file gambar (png, jpg) atau video (mp4)."),
    api_key: str = Depends(validate_api_key)
):
    """
    Menggunakan model Real-ESRGAN dengan skala 4x untuk hasil 'Remini-like'.
    """
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")

    try:
        # Gunakan skala 4x untuk hasil terbaik
        output_url = replicate.run(
            f"nightmareai/real-esrgan:{ESRGAN_MODEL_VERSION}",
            input={"image": url, "scale": 4}
        )
        
        result = ReminiOutput(output_url=output_url)
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model: {str(e)}")