# /zhadev/app/api/v1/tools/audio.py

import time
import replicate
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class VocalRemoverOutput(BaseModel):
    vocals_url: str
    instrumental_url: str

# ID Model Ultimate Vocal Remover di Replicate
UVR_MODEL_VERSION = "23b3543586d434673f3607792742912beb5bbf60b8a2135c3b522a4cb400c436"

@router.get(
    "/vocal-remover",
    response_model=StandardResponse[VocalRemoverOutput],
    responses={503: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Memisahkan vokal dan instrumental dari file audio"
)
async def remove_vocals(
    url: str = Query(..., description="URL ke file audio (mp3, wav, dll)."),
    api_key: str = Depends(validate_api_key)
):
    """
    Menggunakan model Ultimate Vocal Remover (UVR) via Replicate
    untuk memisahkan trek vokal dan instrumental.
    """
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")

    try:
        # Menjalankan prediksi di Replicate
        output = replicate.run(
            f"cj-w-lee/ultimatevocalremover:{UVR_MODEL_VERSION}",
            input={"audio": url}
        )
        
        result = VocalRemoverOutput(
            vocals_url=output['vocals'],
            instrumental_url=output['instrumental']
        )
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        # Replicate API bisa throw error dengan berbagai alasan
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model: {str(e)}")