# /zhadev/app/api/v1/tools/__init__.py

from fastapi import APIRouter

from . import audio
from . import image_enhancement
from . import image_upscaling
from . import video_enhancement
from . import video_upscaling
from . import shipment_tracking
from . import ocr
from . import remini
from . import background_removal
from . import url_shortener
from . import text_to_image
from . import penghitaman

tools_router = APIRouter()

# --- Sesi 1 ---
tools_router.include_router(audio.router, prefix="/audio", tags=["Tools - Audio"])
tools_router.include_router(image_enhancement.router, prefix="/img-enhance", tags=["Tools - Image Processing"])
tools_router.include_router(image_upscaling.router, prefix="/img-upscale", tags=["Tools - Image Processing"])
tools_router.include_router(video_enhancement.router, prefix="/vid-enhance", tags=["Tools - Video Processing"])
tools_router.include_router(video_upscaling.router, prefix="/vid-upscale", tags=["Tools - Video Processing"])

# --- Sesi 2 ---
tools_router.include_router(shipment_tracking.router, prefix="/shipment-tracking", tags=["Tools - Utility"])
tools_router.include_router(ocr.router, prefix="/ocr", tags=["Tools - Image Processing"])
tools_router.include_router(remini.router, prefix="/remini", tags=["Tools - Image Processing"])
tools_router.include_router(background_removal.router, prefix="/remove-bg", tags=["Tools - Image Processing"])
tools_router.include_router(url_shortener.router, prefix="/url-shortener", tags=["Tools - Utility"])

# --- Sesi 3 (Final) ---
tools_router.include_router(text_to_image.router, prefix="/text2img", tags=["Tools - AI Generation"])
tools_router.include_router(penghitaman.router, prefix="/penghitaman", tags=["Tools - AI Generation"])