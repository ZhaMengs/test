# /zhadev/app/api/v1/tools/image_upscaling.py

import time
import replicate
from enum import Enum
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class ScaleType(str, Enum):
    p1080 = "1080p" # Asumsi skala 2x dari SD
    k2 = "2K"       # Skala 2x
    k4 = "4K"       # Skala 4x

class UpscaleOutput(BaseModel):
    output_url: str

ESRGAN_MODEL_VERSION = "42fed1c4974146d4d2414e2be2c523779943453178656d654e0428d34b076219"

@router.get(
    "/",
    response_model=StandardResponse[UpscaleOutput],
    summary="Meningkatkan resolusi gambar (Upscale)"
)
async def upscale_image(
    url: str = Query(..., description="URL ke file gambar (png, jpg)."),
    scale: ScaleType = Query(..., description="Target skala resolusi."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")
        
    scale_map = {"1080p": 2, "2K": 2, "4K": 4}

    try:
        output_url = replicate.run(
            f"nightmareai/real-esrgan:{ESRGAN_MODEL_VERSION}",
            input={"image": url, "scale": scale_map.get(scale, 2)}
        )
        
        result = UpscaleOutput(output_url=output_url)
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model: {str(e)}")