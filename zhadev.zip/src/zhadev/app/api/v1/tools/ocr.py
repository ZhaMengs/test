# /zhadev/app/api/v1/tools/ocr.py

import time
import replicate
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel
from typing import List

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....core.config import settings

router = APIRouter()

class OcrResult(BaseModel):
    text: str
    confidence: float

# ID Model PaddleOCR di Replicate
OCR_MODEL_VERSION = "f530514b1e42f58a556ebd829670df5c68b6b711d51b3624c259850c436b794e"

@router.get(
    "/",
    response_model=StandardResponse[List[OcrResult]],
    summary="Mengekstrak teks dari gambar (OCR)"
)
async def optical_character_recognition(
    url: str = Query(..., description="URL ke file gambar (png, jpg)."),
    api_key: str = Depends(validate_api_key)
):
    start_time = time.time()
    if not settings.REPLICATE_API_TOKEN:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan AI tool tidak dikonfigurasi.")
    
    try:
        # Output dari model ini adalah list of lists, [[text, confidence], ...]
        output = replicate.run(
            f"paddleocr/paddleocr:{OCR_MODEL_VERSION}",
            input={"image": url}
        )
        
        results = [OcrResult(text=item[0], confidence=item[1]) for item in output]

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=results, execution_time_ms=execution_time)
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menjalankan AI model OCR: {str(e)}")