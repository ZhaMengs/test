# /zhadev/app/api/v1/stalker/instagram.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import InstagramCrawler, ContentNotFoundError, CrawlerError

# Model data yang kaya, karena kita berasumsi menggunakan cookie login
class InstagramProfileData(BaseModel):
    id: str
    username: str
    full_name: str = Field(..., alias="fullName")
    avatar_url: str
    biography: str
    external_url: Optional[str] = Field(None, alias="externalUrl")
    follower_count: int
    following_count: int
    post_count: int
    is_private: bool = Field(..., alias="isPrivate")
    is_verified: bool = Field(..., alias="isVerified")

    class Config:
        allow_population_by_field_name = True

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[InstagramProfileData],
    responses={
        403: {"model": ErrorResponse, "description": "Crawler tidak dikonfigurasi dengan benar (cookie `sessionid` hilang)."},
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan, privat, atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari Instagram (Wajib Cookie)",
    description="Memerlukan `sessionid` yang valid di konfigurasi crawler untuk berfungsi."
)
async def get_instagram_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari instagram.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari Instagram.
    """
    start_time = time.time()
    
    try:
        async with InstagramCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)
            
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        if "wajib ada" in str(e).lower() or "sessionid" in str(e).lower() or "cookie" in str(e).lower() or "autentikasi" in str(e).lower():
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")