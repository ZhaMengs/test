# /zhadev/app/api/v1/stalker/tiktok.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, Field

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import TikTokCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk data profil pengguna TikTok
class TikTokProfileData(BaseModel):
    id: str
    unique_id: str = Field(..., alias="uniqueId")
    nickname: str
    avatar_url: str
    signature: str
    is_verified: bool = Field(..., alias="verified")
    follower_count: int = Field(..., alias="followerCount")
    following_count: int = Field(..., alias="followingCount")
    heart_count: int = Field(..., alias="heartCount") # Total likes
    video_count: int = Field(..., alias="videoCount")

    class Config:
        allow_population_by_field_name = True

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[TikTokProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari TikTok",
    description="Masukkan URL profil pengguna TikTok untuk mendapatkan informasi detail dan statistik."
)
async def get_tiktok_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari tiktok.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari TikTok.
    """
    start_time = time.time()
    
    try:
        async with TikTokCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")