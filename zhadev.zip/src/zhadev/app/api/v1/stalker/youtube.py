# /zhadev/app/api/v1/stalker/youtube.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, Field
from typing import Optional

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import YouTubeCrawler, ContentNotFoundError, CrawlerError

class YouTubeChannelData(BaseModel):
    channel_id: str
    title: str
    avatar_url: str
    subscriber_count: str
    video_count: Optional[str] = None
    description: Optional[str] = None
    is_verified: bool

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[YouTubeChannelData],
    responses={
        404: {"model": ErrorResponse, "description": "Channel tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data channel dari YouTube",
    description="Masukkan URL channel YouTube untuk mendapatkan informasi detail."
)
async def get_youtube_channel_data(
    url: str = Query(..., description="URL lengkap channel dari youtube.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi channel dari YouTube.
    """
    start_time = time.time()
    
    try:
        async with YouTubeCrawler() as crawler:
            # Panggil method crawler yang sudah ada
            data = await crawler.get_channel_info(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")