# /zhadev/app/api/v1/stalker/weibo.py

import time
import re
import asyncio
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, Field

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import WeiboCrawler, ContentNotFoundError, CrawlerError

class WeiboProfileData(BaseModel):
    id: int
    screen_name: str
    profile_image_url: str
    description: str
    gender: str
    followers_count: int
    friends_count: int # Following
    statuses_count: int # Post count
    verified: bool
    verified_reason: str

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[WeiboProfileData],
    responses={
        404: {"model": ErrorResponse, "description": "Pengguna tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data profil pengguna dari Weibo",
    description="Masukkan URL profil pengguna Weibo untuk mendapatkan informasi detail."
)
async def get_weibo_profile(
    url: str = Query(..., description="URL lengkap profil pengguna dari weibo.com atau m.weibo.cn."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi profil dari Weibo.
    """
    start_time = time.time()
    
    try:
        async with WeiboCrawler() as crawler:
            # Implementasi aktual untuk mendapatkan data profil
            data = await crawler.get_user_profile(url)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")