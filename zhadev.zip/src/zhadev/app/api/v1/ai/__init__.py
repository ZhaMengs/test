# /zhadev/app/api/v1/ai/__init__.py

from fastapi import APIRouter

from . import gemini, claude, chatgpt4, deepseek, coding, qwen_ai, felo_ai, gpt_logic

ai_router = APIRouter()

ai_router.include_router(gemini.router, prefix="/gemini", tags=["AI - Gemini"])
ai_router.include_router(claude.router, prefix="/claude", tags=["AI - Claude"])
ai_router.include_router(chatgpt4.router, prefix="/chatgpt4", tags=["AI - ChatGPT-4"])
ai_router.include_router(deepseek.router, prefix="/deepseek", tags=["AI - DeepSeek"])
ai_router.include_router(qwen_ai.router, prefix="/qwen", tags=["AI - Qwen"])
ai_router.include_router(coding.router, prefix="/coding", tags=["AI - Coding Assistant"])
ai_router.include_router(felo_ai.router, prefix="/felo", tags=["AI - Felo.ai"])
ai_router.include_router(gpt_logic.router, prefix="/gpt-logic", tags=["AI - GPT Logic"])
ai_router.include_router(character_ai.router, prefix="/character", tags=["AI - Character.AI"])