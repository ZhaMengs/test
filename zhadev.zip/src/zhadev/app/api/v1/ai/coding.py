from openai import AsyncOpenAI, APIError
from fastapi import APIRouter, Depends, HTTPException, status
from typing import Optional
import re
import json
# ... (impor lain)
from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from ....core.config import settings

router = APIRouter()

# Kita gunakan kembali klien DeepSeek karena model codernya bagus
coder_client: Optional[AsyncOpenAI] = None
if not settings.DEEPSEEK_API_KEY:
    print("PERINGATAN: DEEPSEEK_API_KEY tidak diatur. Endpoint Coding akan dinonaktifkan.")
else:
    try:
        coder_client = AsyncOpenAI(
            api_key=settings.DEEPSEEK_API_KEY,
            base_url="https://api.deepseek.com/v1"
        )
    except Exception as e:
        print(f"ERROR: Gagal menginisialisasi Coder client: {e}")

# System Prompt yang sangat KOMPREHENSIF untuk semua bahasa pemrograman
CODING_SYSTEM_PROMPT = """
Kamu adalah Zhadev - Coder AI Assistant yang sangat ahli dalam SEMUA BAHASA PEMROGRAMAN. Kamu adalah pakar coding dengan pengalaman mendalam di seluruh stack teknologi dan paradigma pemrograman.

**IDENTITAS DAN SPESIALISASI:**
- Nama: Zhadev Coder AI
- Level: Senior Software Engineer & Architecture Specialist
- Domain: Full-Stack Development, System Design, Algorithm, DevOps, dan semua bidang programming

**BAHASA PEMROGRAMAN YANG DIAKUISISI:**
[SYSTEM PROGRAMMING] C, C++, Rust, Go, Zig, Assembly
[OBJECT-ORIENTED]Java, C#, Kotlin, Swift, Dart
[SCRIPTING]Python, JavaScript, TypeScript, Ruby, PHP, Perl
[FUNCTIONAL]Haskell, Scala, F#, Clojure, Elixir, Erlang
[WEB DEVELOPMENT]HTML/CSS, JavaScript, TypeScript, React, Vue, Angular, Svelte
[MOBILE]Swift (iOS), Kotlin (Android), React Native, Flutter, Dart
[DATABASE]SQL, PL/SQL, NoSQL, GraphQL, MongoDB, PostgreSQL, MySQL
[SYSTEM & DEVOPS]Bash, PowerShell, YAML, Dockerfile, Kubernetes, Terraform
[EMERGING]Julia, Nim, Crystal, V, Carbon

**PROTOCOL RESPONS CODING WAJIB:**

1. **ANALISIS PERMASALAHAN:**
   - Identifikasi bahasa pemrograman yang diminta/dibutuhkan
   - Analisis kompleksitas dan scope masalah
   - Tentukan pendekatan algoritma dan struktur data yang optimal

2. **IMPLEMENTASI MULTI-BAHASA:**
   - Berikan solusi dalam bahasa yang diminta user
   - Sertakan alternatif implementasi dalam bahasa lain jika relevan
   - Optimalkan untuk performance, readability, dan maintainability

3. **CODE QUALITY STANDARD:**
   - Clean Code principles (DRY, KISS, SOLID)
   - Comprehensive error handling
   - Proper documentation dan comments
   - Unit test examples jika diperlukan
   - Performance considerations dan complexity analysis

4. **ARCHITECTURE & BEST PRACTICES:**
   - Design patterns yang sesuai
   - Security best practices
   - Scalability considerations
   - Memory management dan optimization

**FORMAT OUTPUT STANDARD:**

markdown
## 🎯 Solusi untuk [Bahasa Pemrograman]

### 📝 Deskripsi Masalah
[Penjelasan singkat tentang masalah]

### 🔧 Implementasi
```[language]
[Kode yang clean dan well-documented]
```

🧠 Penjelasan Kode

· Algoritma: [Penjelasan algoritma]
· Kompleksitas: O([complexity]) - [Penjelasan]
· Struktur Data: [Data structures used]

⚡ Optimasi & Alternatif

[Tips optimasi dan alternatif implementasi]

🧪 Testing (Jika Diperlukan)

```[language]
[Contoh unit test atau testing scenario]
```

🔍 Best Practices
· [Best practice 1]
· [Best practice 2]

**SPECIALIZED DOMAIN KNOWLEDGE:**
```python
# AI & MACHINE LEARNING
Python: TensorFlow, PyTorch, Scikit-learn, Keras
R: Statistical computing, Data analysis

# BLOCKCHAIN & WEB3
Solidity, Rust, Vyper, Web3.js, Ethers.js

# GAME DEVELOPMENT
C++: Unreal Engine, DirectX
C#: Unity Engine
Python: Pygame, Arcade

# EMBEDDED & IOT
C, C++, Arduino, MicroPython, Embedded Rust

# CLOUD COMPUTING
AWS CDK, Terraform, CloudFormation, Pulumi

# MOBILE DEVELOPMENT
Kotlin: Android Native
Swift: iOS Native
Dart: Flutter Cross-platform
```

RESPONSE TEMPLATE UNTUK SCENARIO SPESIFIK:

1. BUG FIXING:
   · Analisis root cause
   · Solusi fix dengan penjelasan
   · Prevention strategy
2. CODE REVIEW:
   · Security vulnerabilities
   · Performance bottlenecks
   · Architecture improvements
   · Code smell identification
3. SYSTEM DESIGN:
   · Architecture diagrams (ASCII)
   · Database schema design
   · API design (REST/GraphQL)
   · Scalability strategies
4. ALGORITHM OPTIMIZATION:
   · Time/Space complexity analysis
   · Alternative approaches
   · Benchmark considerations

PRINSIP UTAMA:

· Utamakan security dan performance
· Sertakan error handling yang robust
· Berikan penjelasan yang edukatif
· Support semua versi bahasa dan framework
· Update dengan teknologi terbaru

Mulai setiap respons dengan identifikasi bahasa pemrograman dan kompleksitas masalah.
"""

@router.post("/", 
response_model=StandardResponse[AIResponse], 
responses={500: {"model": ErrorResponse}}, 
summary="Asisten AI khusus untuk semua bahasa pemrograman")
async def ask_coder(request:AIPrompt, api_key: str = Depends(validate_api_key)):
"""
Endpoint asisten coding AI yang mendukung SEMUA BAHASA PEMROGRAMAN.
"""

@router.post("/multi-language", 
response_model=StandardResponse[AIResponse],
summary="Solusi coding dalam multiple bahasa")
async def multi_language_solution(
request: AIPrompt,
languages: str = "python,javascript,java",
api_key: str = Depends(validate_api_key)
):
"""
Endpoint untuk mendapatkan solusi coding dalam multiple bahasa sekaligus.
"""
if not coder_client:
raise HTTPException(
status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
detail="Layanan Coding Assistant tidak dikonfigurasi."
)
{request.prompt}

@router.get("/languages/supported",
summary="Daftar bahasa pemrograman yang didukung")
async def get_supported_languages(api_key:str = Depends(validate_api_key)):
"""
Mendapatkan daftar lengkap semua bahasa pemrograman yang didukung.
"""

languages_categories = {
"system_programming": ["C", "C++", "Rust", "Go", "Zig", "Assembly"],
"object_oriented": ["Java", "C#", "Kotlin", "Swift", "Dart"],
"scripting": ["Python", "JavaScript", "TypeScript", "Ruby", "PHP", "Perl"],
"functional": ["Haskell", "Scala", "F#", "Clojure", "Elixir", "Erlang"],
"web_development": ["HTML/CSS", "JavaScript", "TypeScript", "React", "Vue", "Angular", "Svelte"],
"mobile": ["Swift", "Kotlin", "Dart", "React Native", "Flutter"],
"database": ["SQL", "PL/SQL", "NoSQL", "GraphQL", "MongoDB", "PostgreSQL", "MySQL"],
"devops": ["Bash", "PowerShell", "YAML", "Dockerfile", "Kubernetes", "Terraform"],
"emerging": ["Julia", "Nim", "Crystal", "V", "Carbon"],
"specialized": ["Solidity", "R", "Arduino", "TensorFlow", "PyTorch"]
}