# /zhadev/app/api/v1/ai/character_ai.py

import json
import uuid
import time
import httpx
from fastapi import APIRouter, HTTPException, status, Depends
from typing import Optional, Dict, Any, List
import random

from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIResponse, CharacterAIRequest
from ....core.config import settings

router = APIRouter()

class CharacterAIClient:
    def __init__(self):
        self.base_url = "https://beta.character.ai"
        self.client = None
        self.token = None
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.9",
            "Content-Type": "application/json",
            "Origin": "https://beta.character.ai",
            "Referer": "https://beta.character.ai/",
        }
        
    async def __aenter__(self):
        self.client = httpx.AsyncClient(
            headers=self.headers,
            timeout=30.0,
            follow_redirects=True
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.client:
            await self.client.aclose()
            
    async def login(self, email: str, password: str) -> bool:
        """Login ke Character.AI untuk mendapatkan token"""
        try:
            # Dapatkan CSRF token terlebih dahulu
            await self.client.get(f"{self.base_url}/login/")
            
            login_data = {
                "email": cp.zhadev@gmail.com,
                "password": kontol11223344445566@,
                "username": "zhadev",
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/auth/login/",
                json=login_data
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    self.token = data.get("token")
                    if self.token:
                        self.headers["Authorization"] = f"Token {self.token}"
                    return True
            return False
            
        except Exception as e:
            print(f"Login error: {e}")
            return False
            
    async def get_public_characters(self, search_query: str = "", limit: int = 10) -> List[Dict[str, Any]]:
        """Mendapatkan daftar karakter publik"""
        try:
            params = {
                "page": 1,
                "is_suggested": "false",
                "query": search_query,
                "username": "",
            }
            
            response = await self.client.get(
                f"{self.base_url}/chat/characters/search/",
                params=params
            )
            
            if response.status_code == 200:
                data = response.json()
                return data.get("characters", [])[:limit]
            return []
            
        except Exception as e:
            print(f"Error getting characters: {e}")
            return []
            
    async def start_chat(self, character_id: str) -> Optional[str]:
        """Memulai chat baru dengan karakter"""
        try:
            data = {
                "character_external_id": character_id,
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/chatroom/create/",
                json=data
            )
            
            if response.status_code == 200:
                chat_data = response.json()
                return chat_data.get("external_id")
            return None
            
        except Exception as e:
            print(f"Error starting chat: {e}")
            return None
            
    async def send_message(self, character_id: str, message: str, chat_id: Optional[str] = None) -> Dict[str, Any]:
        """Mengirim pesan ke karakter dan mendapatkan respons"""
        try:
            if not chat_id:
                chat_id = await self.start_chat(character_id)
                if not chat_id:
                    raise Exception("Gagal membuat chat room")
            
            # Generate unique IDs
            history_external_id = str(uuid.uuid4())
            turn_key = str(uuid.uuid4())
            primary_candidate_id = str(uuid.uuid4())
            
            payload = {
                "character_external_id": character_id,
                "history_external_id": history_external_id,
                "text": message,
                "tgt": character_id,
                "turn_key": turn_key,
                "staging": False,
                "stream_params": None,
                "model_server_address": None,
                "model_server_address_exp": None,
                "override_prefix": None,
                "override_rank": None,
                "rank_candidates": None,
                "filter_candidates": None,
                "prefix_limit": None,
                "prefix_token_limit": None,
                "livetune_coeff": None,
                "livetune_force": None,
                "primary_candidate_id": primary_candidate_id,
                "candidate_origin": "chat",
                "release_channel": "default",
                "responses_count": 1,
            }
            
            response = await self.client.post(
                f"{self.base_url}/chat/streaming/",
                json=payload
            )
            
            if response.status_code == 200:
                return await self._parse_stream_response(response)
            else:
                raise Exception(f"API error: {response.status_code}")
                
        except Exception as e:
            print(f"Error sending message: {e}")
            return {"error": str(e)}
            
    async def _parse_stream_response(self, response: httpx.Response) -> Dict[str, Any]:
        """Parse streaming response dari Character.AI"""
        try:
            content = response.text
            lines = content.strip().split('\n')
            
            for line in lines:
                if line.startswith('data: '):
                    data_str = line[6:]  # Remove 'data: ' prefix
                    if data_str and data_str != '[DONE]':
                        try:
                            data = json.loads(data_str)
                            if 'replies' in data and data['replies']:
                                return {
                                    "response": data['replies'][0],
                                    "candidates": data.get('candidates', []),
                                    "turn_key": data.get('turn_key')
                                }
                        except json.JSONDecodeError:
                            continue
                            
            return {"error": "Tidak dapat parse respons"}
            
        except Exception as e:
            return {"error": f"Parse error: {str(e)}"}

# Instance global client
character_client = CharacterAIClient()

# Karakter publik populer sebagai fallback
POPULAR_CHARACTERS = {
    "psychologist": "d6OOS-OJfS3Pp3C6YFpLh5L2p6vCgQN1J9IQLtPc5WQ",  # Psychologist
    "philosopher": "8B1v4wYFQ7VlqGY6gRgbz0S9C2hJwA8a3nQZLXqRf5s",   # Philosopher
    "helper": "f9vQwN7YFQ7VlqGY6gRgbz0S9C2hJwA8a3nQZLXqRf5s",      # AI Helper
}

@router.post("/chat", response_model=StandardResponse[AIResponse], 
             responses={500: {"model": ErrorResponse}}, 
             summary="Mengirim pesan ke Character AI")
async def ask_character_ai(
    request: CharacterAIRequest, 
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk berinteraksi dengan Character AI.
    
    Parameters:
    - character_id: ID karakter spesifik (opsional)
    - character_name: Nama karakter untuk search (opsional) 
    - message: Pesan yang ingin dikirim
    - use_public: Gunakan karakter publik jika True
    """
    try:
        async with character_client as client:
            character_id = request.character_id
            
            # Jika tidak ada character_id, cari berdasarkan nama atau gunakan default
            if not character_id:
                if request.character_name:
                    # Search karakter berdasarkan nama
                    characters = await client.get_public_characters(request.character_name, limit=5)
                    if characters:
                        character_id = characters[0]['external_id']
                    else:
                        # Fallback ke karakter populer
                        character_id = POPULAR_CHARACTERS.get("helper")
                else:
                    # Gunakan karakter helper default
                    character_id = POPULAR_CHARACTERS.get("helper")
            
            if not character_id:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Character ID tidak valid dan tidak dapat menemukan karakter alternatif"
                )
            
            # Kirim pesan
            result = await client.send_message(character_id, request.message)
            
            if "error" in result:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Error dari Character AI: {result['error']}"
                )
            
            response_text = result.get("response", "Tidak ada respons yang diterima")
            
            return StandardResponse(data=AIResponse(text=response_text))
            
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan internal: {str(e)}"
        )

@router.get("/characters/search", summary="Mencari karakter publik di Character AI")
async def search_characters(
    query: str = "",
    limit: int = 10,
    api_key: str = Depends(validate_api_key)
):
    """Mencari karakter publik yang tersedia"""
    try:
        async with character_client as client:
            characters = await client.get_public_characters(query, limit)
            
            return StandardResponse(data={
                "characters": characters,
                "count": len(characters)
            })
            
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error mencari karakter: {str(e)}"
        )

@router.get("/characters/popular", summary="Mendapatkan daftar karakter populer")
async def get_popular_characters(api_key: str = Depends(validate_api_key)):
    """Mendapatkan daftar karakter populer yang sudah dikurasi"""
    popular_list = []
    
    for name, char_id in POPULAR_CHARACTERS.items():
        popular_list.append({
            "name": name,
            "id": char_id,
            "description": f"Karakter {name} yang populer"
        })
    
    return StandardResponse(data={"characters": popular_list})

# Model request tambahan
class CharacterAIRequest:
    def __init__(
        self,
        message: str,
        character_id: Optional[str] = None,
        character_name: Optional[str] = None,
        use_public: bool = True
    ):
        self.message = message
        self.character_id = character_id
        self.character_name = character_name
        self.use_public = use_public