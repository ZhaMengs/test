# /zhadev/app/api/v1/ai/chatgpt4.py

from openai import AsyncOpenAI, APIError
from fastapi import APIRouter, Depends, HTTPException, status

from ..models import StandardResponse, validate_api_key, ErrorResponse
from .models import AIPrompt, AIResponse
from ....core.config import settings

router = APIRouter()

openai_client: Optional[AsyncOpenAI] = None
if not settings.CHATGPT_API_KEY:
    print("PERINGATAN: CHATGPT_API_KEY tidak diatur. Endpoint ChatGPT akan dinonaktifkan.")
else:
    try:
        openai_client = AsyncOpenAI(api_key=settings.CHATGPT_API_KEY)
    except Exception as e:
        print(f"ERROR: Gagal menginisialisasi OpenAI client: {e}")

@router.post("/", response_model=StandardResponse[AIResponse], responses={500: {"model": ErrorResponse}}, summary="Mengirim prompt ke OpenAI ChatGPT-4")
async def ask_chatgpt4(request: AIPrompt, api_key: str = Depends(validate_api_key)):
    if not openai_client:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Layanan ChatGPT tidak dikonfigurasi di server.")
    try:
        response = await openai_client.chat.completions.create(
            model="gpt-4o", # Menggunakan model terbaru gpt-4o
            messages=[{"role": "user", "content": request.prompt}]
        )
        response_text = response.choices[0].message.content
        result = AIResponse(text=response_text)
        return StandardResponse(data=result)
    except APIError as e:
        print(f"ERROR: Terjadi kesalahan pada API OpenAI: {e}")
        raise HTTPException(status_code=e.status_code or 500, detail=f"Error dari API OpenAI: {e.message}")