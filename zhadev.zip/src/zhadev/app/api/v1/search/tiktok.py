# /zhadev/app/api/v1/search/tiktok.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import TikTokCrawler, ContentNotFoundError, CrawlerError

class TikTokSearchResult(BaseModel):
    video_id: str
    description: str
    video_url: str
    cover_url: str
    author_nickname: str
    play_count: int
    like_count: int

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[TikTokSearchResult]],
    responses={404: {"model": ErrorResponse}, 500: {"model": ErrorResponse}},
    summary="Mencari video di TikTok",
)
async def search_tiktok(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian video di TikTok.
    """
    start_time = time.time()
    
    try:
        async with TikTokCrawler() as crawler:
          
          data = await crawler.search(q)
          
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")