# /zhadev/app/api/v1/search/__init__.py

from fastapi import APIRouter

# Impor router dari semua file implementasi
from . import bstation, bilibili, weather, douyin, earthquake
from . import pinterest, prayer_schedule, anime_schedule, donghua_schedule, recipes
from . import spotify, tiktok, twitter, weibo, xiaohongshu
from . import youtube, donghub

# Buat router utama untuk semua endpoint search
search_router = APIRouter()

# --- Sesi 1 ---
search_router.include_router(bstation.router, prefix="/bstation", tags=["Search - Bstation"])
search_router.include_router(bilibili.router, prefix="/bilibili", tags=["Search - Bilibili"])
search_router.include_router(weather.router, prefix="/weather", tags=["Search - Weather"])
search_router.include_router(douyin.router, prefix="/douyin", tags=["Search - Douyin"])
search_router.include_router(earthquake.router, prefix="/earthquake", tags=["Search - Earthquake"])

# --- Sesi 2 ---
search_router.include_router(pinterest.router, prefix="/pinterest", tags=["Search - Pinterest"])
search_router.include_router(prayer_schedule.router, prefix="/prayer-schedule", tags=["Search - Prayer Schedule"])
search_router.include_router(anime_schedule.router, prefix="/anime-schedule", tags=["Search - Anime Schedule"])
search_router.include_router(donghua_schedule.router, prefix="/donghua-schedule", tags=["Search - Donghua Schedule"])
search_router.include_router(recipes.router, prefix="/recipes", tags=["Search - Recipes"])

# --- Sesi 3 ---
search_router.include_router(spotify.router, prefix="/spotify", tags=["Search - Spotify"])
search_router.include_router(tiktok.router, prefix="/tiktok", tags=["Search - TikTok"])
search_router.include_router(twitter.router, prefix="/twitter", tags=["Search - Twitter"])
search_router.include_router(weibo.router, prefix="/weibo", tags=["Search - Weibo"])
search_router.include_router(xiaohongshu.router, prefix="/xiaohongshu", tags=["Search - Xiaohongshu"])

# --- Sesi 4 (Final) ---
search_router.include_router(youtube.router, prefix="/youtube", tags=["Search - YouTube"])
search_router.include_router(donghub.router, prefix="/donghub", tags=["Search - Donghub"])