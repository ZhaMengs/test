# /zhadev/app/api/v1/search/recipes.py

import time
from typing import List, Optional, Dict
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import BaseCrawler, CrawlerError

class Ingredient(BaseModel):
    name: str
    measure: str

class RecipeData(BaseModel):
    id: str
    name: str
    category: str
    area: str
    instructions: str
    thumbnail_url: str
    youtube_url: Optional[str] = None
    source_url: Optional[str] = None
    ingredients: List[Ingredient]

router = APIRouter()
RECIPE_API_URL = "http://googleusercontent.com/themealdb.com/0"

def _transform_meal_data(meal: Dict) -> RecipeData:
    """Helper untuk mengubah data mentah API menjadi model yang bersih."""
    ingredients = []
    for i in range(1, 21):
        ing_key = f"strIngredient{i}"
        measure_key = f"strMeasure{i}"
        if meal.get(ing_key) and meal[ing_key].strip():
            ingredients.append(Ingredient(name=meal[ing_key], measure=meal[measure_key]))
    
    return RecipeData(
        id=meal['idMeal'],
        name=meal['strMeal'],
        category=meal['strCategory'],
        area=meal['strArea'],
        instructions=meal['strInstructions'],
        thumbnail_url=meal['strMealThumb'],
        youtube_url=meal.get('strYoutube'),
        source_url=meal.get('strSource'),
        ingredients=ingredients
    )

@router.get(
    "/",
    response_model=StandardResponse[List[RecipeData]],
    summary="Mencari resep masakan berdasarkan nama",
    description="Menggunakan API publik dari TheMealDB.com."
)
async def search_recipes(
    q: str = Query(..., description="Nama masakan yang ingin dicari (contoh: 'Arrabiata')."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mencari resep masakan.
    """
    start_time = time.time()
    params = {"s": q}
    
    try:
        async with BaseCrawler() as crawler:
            data = await crawler.fetch_json(RECIPE_API_URL, params=params)
        
        results: List[RecipeData] = []
        if data and data.get("meals"):
            for meal in data["meals"]:
                results.append(_transform_meal_data(meal))
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=results, execution_time_ms=execution_time)
        
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Gagal menghubungi API resep: {e}")