# /zhadev/app/api/v1/search/youtube.py

import time
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import YouTubeCrawler, ContentNotFoundError, CrawlerError

class YouTubeSearchResult(BaseModel):
    video_id: str
    title: str
    url: str
    author: str
    view_count_text: Optional[str] = None
    length_text: Optional[str] = None
    thumbnail_url: str

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[YouTubeSearchResult]],
    responses={
        404: {"model": ErrorResponse, "description": "Tidak ada hasil yang ditemukan."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mencari video di YouTube",
    description="Masukkan query pencarian untuk mendapatkan daftar video yang relevan dari YouTube."
)
async def search_youtube(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian video di YouTube.
    """
    start_time = time.time()
    
    try:
        async with YouTubeCrawler() as crawler:
          
          data = await crawler.search(q)
          
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")