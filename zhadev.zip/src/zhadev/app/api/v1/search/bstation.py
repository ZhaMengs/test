# /zhadev/app/api/v1/search/bstation.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import BstationCrawler, ContentNotFoundError, CrawlerError

# Definisikan model Pydantic spesifik untuk hasil pencarian Bstation
class BstationSearchResult(BaseModel):
    title: str
    url: str
    cover_url: str
    author: str
    duration: str # format "MM:SS"

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[List[BstationSearchResult]],
    responses={
        404: {"model": ErrorResponse, "description": "Tidak ada hasil yang ditemukan."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mencari video di Bstation (bilibili.tv)",
    description="Masukkan query pencarian untuk mendapatkan daftar video yang relevan."
)
async def search_bstation(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian di Bstation.
    """
    start_time = time.time()
    
    try:
        async with BstationCrawler() as crawler:
          
          data = await crawler.search(q)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")