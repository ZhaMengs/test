# /zhadev/app/api/v1/search/twitter.py

import time
from typing import List
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import TwitterCrawler, TwitterTweetData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    # Gunakan kembali model TwitterTweetData karena strukturnya mirip
    response_model=StandardResponse[List[TwitterTweetData]],
    responses={
        403: {"model": ErrorResponse, "description": "Crawler tidak dikonfigurasi dengan benar (token autentikasi hilang)."},
        404: {"model": ErrorResponse, "description": "Tidak ada hasil pencarian."},
        500: {"model": ErrorResponse}
    },
    summary="Mencari Tweet di Twitter/X (Wajib Autentikasi)",
    description="Memerlukan `auth_token` dan `ct0` yang valid di konfigurasi crawler."
)
async def search_twitter(
    q: str = Query(..., description="Kata kunci pencarian."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk melakukan pencarian Tweet di Twitter/X.
    """
    start_time = time.time()
    
    try:
        async with TwitterCrawler() as crawler:
          
          data = await crawler.search(q)

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        if "wajib diisi" in str(e):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")