# /zhadev/app/api/v1/random/__init__.py

from fastapi import APIRouter

from . import quotes
from . import anime
from . import donghua

random_router = APIRouter()

random_router.include_router(quotes.router, prefix="/quotes", tags=["Random - General Quotes"])
random_router.include_router(anime.router, prefix="/anime-quotes", tags=["Random - Anime Quotes"])
random_router.include_router(donghua.router, prefix="/donghua-quotes", tags=["Random - Donghua/Novel Quotes"])