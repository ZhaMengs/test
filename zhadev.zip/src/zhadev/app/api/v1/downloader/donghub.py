# /zhadev/app/api/v1/downloader/donghub.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel
from typing import Optional

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import DonghubCrawler, ContentNotFoundError, CrawlerError

router = APIRouter()

class DonghuaDownloadData(BaseModel):
    """Model respons spesifik untuk endpoint unduhan Donghub."""
    episode_title: str
    series_title: str
    download_url: str
    source_page: str

@router.get(
    "/",
    response_model=StandardResponse[DonghuaDownloadData],
    responses={
        404: {"model": ErrorResponse, "description": "Serial Donghua atau episode spesifik tidak ditemukan."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mencari dan mendapatkan link unduhan episode Donghua dari Donghub",
    description="Endpoint ini melakukan pencarian, menemukan seri, mencari episode yang diminta, lalu mengekstrak link unduhannya."
)
async def get_donghub_download_link(
    s: str = Query(..., description="Kata kunci pencarian untuk judul Donghua (contoh: 'battle through the heavens')."),
    episode: int = Query(..., description="Nomor episode yang ingin diunduh."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint orkestrasi untuk mencari dan mengunduh episode dari Donghub.
    """
    start_time = time.time()
    
    try:
        async with DonghubCrawler() as crawler:
            # Langkah 1: Cari serial Donghua
            search_results = await crawler.search(query=s)
            if not search_results:
                raise ContentNotFoundError(f"Tidak ada hasil pencarian untuk '{s}'.")
            
            # Ambil hasil pertama yang paling relevan
            series_url = search_results[0].url
            
            # Langkah 2: Dapatkan info detail serial, termasuk daftar episode
            series_info = await crawler.get_info(title_url=series_url)
            
            # Langkah 3: Cari episode yang cocok berdasarkan nomor
            target_episode = next((ep for ep in series_info.episodes if ep.episode_number == episode), None)
            if not target_episode:
                raise ContentNotFoundError(f"Episode {episode} tidak ditemukan untuk serial '{series_info.english_title}'.")

            # Langkah 4: Dapatkan link download dari episode
            download_links = await crawler.get_download_links(target_episode.episode_url)
            
            result = DonghuaDownloadData(
                episode_title=target_episode.episode_title,
                series_title=series_info.english_title,
                download_url=download_links['download_url'],
                source_page=target_episode.episode_url
            )

        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=result, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")