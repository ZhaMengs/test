# /zhadev/app/api/v1/downloader/__init__.py

from fastapi import APIRouter

# Impor dari semua file endpoint yang telah kita buat
from . import bstation, bilibili, capcut, douyin
from . import facebook, dailymotion, gdrive, github, instagram
from . import mediafire, pinterest, pixeldrain, spotify, snackvideo
from . import terabox, threads, tiktok, twitter, weibo, youtube, xiaohongshu, donghub

# Buat router utama untuk semua endpoint downloader
downloader_router = APIRouter()

# --- Platform China ---
downloader_router.include_router(douyin.router, prefix="/douyin", tags=["Downloader - Douyin"])
downloader_router.include_router(bilibili.router, prefix="/bilibili", tags=["Downloader - Bilibili"])
downloader_router.include_router(bstation.router, prefix="/bstation", tags=["Downloader - Bstation"])
downloader_router.include_router(weibo.router, prefix="/weibo", tags=["Downloader - Weibo"])
downloader_router.include_router(xiaohongshu.router, prefix="/xiaohongshu", tags=["Downloader - Xiaohongshu"])

# --- Platform Global ---
downloader_router.include_router(capcut.router, prefix="/capcut", tags=["Downloader - Capcut"])
downloader_router.include_router(dailymotion.router, prefix="/dailymotion", tags=["Downloader - Dailymotion"])
downloader_router.include_router(donghub.router, prefix="/donghub", tags=["Downloader - Donghub"])
downloader_router.include_router(facebook.router, prefix="/facebook", tags=["Downloader - Facebook"])
downloader_router.include_router(gdrive.router, prefix="/gdrive", tags=["Downloader - GDrive"])
downloader_router.include_router(github.router, prefix="/github", tags=["Downloader - GitHub"])
downloader_router.include_router(instagram.router, prefix="/instagram", tags=["Downloader - Instagram"])
downloader_router.include_router(mediafire.router, prefix="/mediafire", tags=["Downloader - Mediafire"])
downloader_router.include_router(pinterest.router, prefix="/pinterest", tags=["Downloader - Pinterest"])
downloader_router.include_router(pixeldrain.router, prefix="/pixeldrain", tags=["Downloader - Pixeldrain"])
downloader_router.include_router(snackvideo.router, prefix="/snackvideo", tags=["Downloader - Snackvideo"])
downloader_router.include_router(spotify.router, prefix="/spotify", tags=["Downloader - Spotify"])
downloader_router.include_router(terabox.router, prefix="/terabox", tags=["Downloader - Terabox"])
downloader_router.include_router(threads.router, prefix="/threads", tags=["Downloader - Threads"])
downloader_router.include_router(terabox.router, prefix="/tiktok", tags=["Downloader - TikTok"])
downloader_router.include_router(twitter.router, prefix="/twitter", tags=["Downloader - Twitter"])
downloader_router.include_router(youtube.router, prefix="/youtube", tags=["Downloader - YouTube"])