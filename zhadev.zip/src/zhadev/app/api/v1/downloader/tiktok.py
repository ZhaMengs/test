import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

# Impor komponen inti: validator, model respons, dan crawler
from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import TikTokCrawler, TikTokVideoData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[TikTokVideoData],
    responses={
        404: {"model": ErrorResponse, "description": "Video tidak ditemukan, bersifat privat, atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau saat parsing halaman."}
    },
    summary="Mengambil data video dari TikTok",
    description="Masukkan URL video TikTok (termasuk URL pendek seperti vm.tiktok.com) untuk mendapatkan metadata lengkap, statistik, dan link unduhan video tanpa watermark."
)
async def get_tiktok_data(
    url: str = Query(..., description="URL lengkap video dari tiktok.com atau vm.tiktok.com."),
    # Setiap endpoint diamankan dengan dependency validate_api_key ini
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi video komprehensif dari TikTok.
    """
    start_time = time.time()
    
    try:
        # Menggunakan `async with` memastikan sesi crawler (klien httpx) ditutup dengan benar
        async with TikTokCrawler() as crawler:
            data = await crawler.get_video_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        # Menangani kasus di mana crawler tidak dapat menemukan konten
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except CrawlerError as e:
        # Menangkap semua error lain dari lapisan crawler (termasuk ParsingError)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Crawler Error: {str(e)}"
        )
    except Exception as e:
        # Menangkap error tak terduga lainnya untuk keamanan
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan internal yang tidak terduga: {str(e)}"
        )