# /zhadev/app/api/v1/downloader/capcut.py

import time
from fastapi import APIRouter, Depends, Query, HTTPException, status

from ..models import StandardResponse, ErrorResponse, validate_api_key
from ....crawlers import CapcutCrawler, CapcutTemplateData, ContentNotFoundError, CrawlerError

router = APIRouter()

@router.get(
    "/",
    response_model=StandardResponse[CapcutTemplateData],
    responses={
        404: {"model": ErrorResponse, "description": "Konten tidak ditemukan atau URL tidak valid."},
        500: {"model": ErrorResponse, "description": "Terjadi error internal pada server atau crawler."}
    },
    summary="Mengambil data template dari CapCut",
    description="Masukkan URL template CapCut untuk mendapatkan metadata lengkap dan link video preview."
)
async def get_capcut_data(
    url: str = Query(..., description="URL lengkap template dari capcut.com."),
    api_key: str = Depends(validate_api_key)
):
    """
    Endpoint untuk mengekstrak informasi template dari CapCut.
    """
    start_time = time.time()
    
    try:
        async with CapcutCrawler() as crawler:
            data = await crawler.get_template_data(url)
        
        execution_time = (time.time() - start_time) * 1000
        return StandardResponse(data=data, execution_time_ms=execution_time)

    except ContentNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except CrawlerError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Crawler Error: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Terjadi kesalahan internal: {str(e)}")