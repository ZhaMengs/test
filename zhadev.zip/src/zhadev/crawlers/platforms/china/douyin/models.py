from pydantic import BaseModel, Field
from typing import List, Optional, Any

# ==============================================================================
# Model Raw API (Mencerminkan respons JSON asli dari Douyin)
# ==============================================================================
# Model-model ini digunakan untuk memvalidasi dan mem-parsing respons mentah
# dari API Douyin menggunakan Pydantic. Ini memastikan ketahanan terhadap
# perubahan kecil pada API dan memberikan type-hinting yang jelas.

class URLListItem(BaseModel):
    url_list: List[str]

class VideoRaw(BaseModel):
    play_addr: Optional[URLListItem] = Field(None, alias="play_addr")
    play_addr_wm: Optional[URLListItem] = Field(None, alias="play_addr_wm")
    cover: Optional[URLListItem] = None
    origin_cover: Optional[URLListItem] = None
    height: int
    width: int
    ratio: str
    duration: int

class MusicRaw(BaseModel):
    id_str: str
    title: str
    author: str
    play_url: Optional[URLListItem] = None

class AuthorRaw(BaseModel):
    uid: str
    nickname: str
    signature: str
    avatar_thumb: Optional[URLListItem] = None
    unique_id: Optional[str] = "" # ID unik, kadang kosong
    short_id: Optional[str] = "" # ID pendek, kadang kosong

class StatisticsRaw(BaseModel):
    digg_count: int = Field(..., alias="digg_count")
    comment_count: int = Field(..., alias="comment_count")
    collect_count: int = Field(..., alias="collect_count")
    share_count: int = Field(..., alias="share_count")

class AwemeDetailRaw(BaseModel):
    aweme_id: str
    desc: str
    create_time: int
    author: AuthorRaw
    music: Optional[MusicRaw] = None
    video: Optional[VideoRaw] = None
    statistics: StatisticsRaw
    # Douyin juga mendukung postingan gambar
    images: Optional[List[Any]] = None

class DouyinAPIRawResponse(BaseModel):
    status_code: int
    aweme_detail: Optional[AwemeDetailRaw] = None
    status_msg: Optional[str] = ""

# ==============================================================================
# Model Data yang Diproses (Output Akhir dari Crawler)
# ==============================================================================
# Model ini adalah representasi data yang bersih dan terstruktur yang akan
# dikembalikan oleh crawler ke lapisan API atau aplikasi web.

class AuthorInfo(BaseModel):
    uid: str
    nickname: str
    unique_id: str
    signature: str
    avatar_url: Optional[str] = None

class MusicInfo(BaseModel):
    id: str
    title: str
    author: str
    play_url: Optional[str] = None

class VideoInfo(BaseModel):
    height: int
    width: int
    ratio: str
    duration_ms: int
    url_with_watermark: Optional[str] = None
    url_without_watermark: Optional[str] = None
    cover_url: Optional[str] = None

class StatisticsInfo(BaseModel):
    likes: int
    comments: int
    favorites: int
    shares: int

class DouyinVideoData(BaseModel):
    """Output akhir yang komprehensif dari Douyin Crawler."""
    status: str = "success"
    platform: str = "douyin"
    aweme_id: str
    description: str
    created_at_timestamp: int
    author: AuthorInfo
    statistics: StatisticsInfo
    music: Optional[MusicInfo] = None
    video: Optional[VideoInfo] = None
    # Jika postingan berupa album foto
    is_image_album: bool = False
    image_urls: Optional[List[str]] = None
