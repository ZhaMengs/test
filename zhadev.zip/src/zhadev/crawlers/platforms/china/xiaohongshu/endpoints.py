class XiaohongshuEndpoints:
    """
    Menyimpan endpoint API utama untuk Xiaohongshu (versi Web).
    """
    # Domain utama untuk API
    API_DOMAIN: str = "https://edith.xiaohongshu.com"
    NOTE_DETAIL: str = f"{API_DOMAIN}/api/sns/web/v1/feed"
    NOTE_COMMENTS: str = f"{API_DOMAIN}/api/sns/web/v2/comment/page"
