from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================

class ImageInfoRaw(BaseModel):
    url_default: Optional[str] = Field(None, alias="urlDefault")
    url_pre_shrink: Optional[str] = Field(None, alias="urlPreShrink")
    width: int
    height: int

class VideoInfoRaw(BaseModel):
    media: Optional[Dict[str, Any]] = None
    stream: Optional[Dict[str, List[Dict[str, Any]]]] = None

class UserRaw(BaseModel):
    user_id: str = Field(..., alias="userId")
    nickname: str
    avatar: str
    
class NoteDetailRaw(BaseModel):
    note_id: str = Field(..., alias="noteId")
    note_type: str = Field(..., alias="type")
    title: str
    desc: str
    time: int
    image_list: Optional[List[ImageInfoRaw]] = Field(None, alias="imageList")
    video: Optional[VideoInfoRaw] = None
    user: UserRaw
    interact_info: Dict[str, Any] = Field(..., alias="interactInfo")

class NoteAPIData(BaseModel):
    items: List[Dict[str, Any]]

class XiaohongshuAPIRawResponse(BaseModel):
    success: bool
    code: int
    msg: str
    data: NoteAPIData

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class AuthorInfo(BaseModel):
    user_id: str
    nickname: str
    avatar_url: str

class ImageInfo(BaseModel):
    url: str
    width: int
    height: int

class VideoStreamInfo(BaseModel):
    format: str
    url: str
    height: int
    width: int
    
class VideoDetail(BaseModel):
    cover_url: str
    duration_ms: int
    streams: List[VideoStreamInfo]

class StatisticsInfo(BaseModel):
    likes: int
    favorites: int
    comments: int
    shares: int

class XiaohongshuNoteData(BaseModel):
    """Output akhir yang komprehensif dari Xiaohongshu Crawler."""
    status: str = "success"
    platform: str = "xiaohongshu"
    note_id: str
    note_type: str
    title: str
    description: str
    created_at_timestamp: int
    author: AuthorInfo
    statistics: StatisticsInfo
    images: Optional[List[ImageInfo]] = None
    video: Optional[VideoDetail] = None
