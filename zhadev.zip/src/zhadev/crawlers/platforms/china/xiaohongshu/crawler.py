import os
import yaml
import json
from typing import Any, Dict

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import XiaohongshuEndpoints
from .models import XiaohongshuAPIRawResponse, XiaohongshuNoteData, AuthorInfo, StatisticsInfo, ImageInfo, VideoDetail, VideoStreamInfo
from .utils import extract_note_id, XSignManager

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class XiaohongshuCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk mengambil data postingan (note) dari Xiaohongshu.
    Crawler ini mengimplementasikan mekanisme signature X-Sign untuk otentikasi.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['xiaohongshu']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))
        
        self.xsign_salt = config.get('x_sign_salt')
        if not self.xsign_salt:
            raise CrawlingError("`x_sign_salt` tidak ditemukan di config.yaml.")
            
        self.xsign_manager = XSignManager(salt=self.xsign_salt)

    async def get_note_data(self, url: str) -> XiaohongshuNoteData:
        """
        Metode utama untuk mengambil dan memproses data dari URL Xiaohongshu.

        :param url: URL postingan Xiaohongshu yang valid.
        :return: Objek Pydantic XiaohongshuNoteData yang berisi informasi lengkap.
        """
        # 1. Ekstrak Note ID dari URL
        note_id = await extract_note_id(url)

        # 2. Siapkan payload dan path API untuk X-Sign
        api_path = "/api/sns/web/v1/feed"
        payload = {"source_note_id": note_id}
        # Konversi ke string JSON padat (tanpa spasi) karena X-Sign sensitif terhadap ini
        payload_str = json.dumps(payload, separators=(',', ':'))

        # 3. Hasilkan signature X-Sign
        signature = self.xsign_manager.generate_xsign(api_path=api_path, data=payload_str)

        # 4. Buat header khusus untuk permintaan ini
        request_headers = self.headers.copy()
        request_headers['x-sign'] = signature
        
        # 5. Lakukan POST request ke API
        # Meskipun kita hanya "mengambil" data, API detail XHS menggunakan metode POST
        api_response_json = await self.post_json(
            url=XiaohongshuEndpoints.NOTE_DETAIL,
            data=payload_str,
            headers=request_headers
        )

        # 6. Validasi dan parsing respons mentah
        try:
            validated_response = XiaohongshuAPIRawResponse.model_validate(api_response_json)
            if not validated_response.success or not validated_response.data.items:
                raise ContentNotFoundError(f"API Xiaohongshu mengembalikan error: {validated_response.msg}")
            
            # Data postingan biasanya adalah item pertama dalam list
            note_detail_raw = validated_response.data.items[0]['note_card']
        except (ValidationError, IndexError, KeyError) as e:
            raise ParsingError(f"Struktur respons API Xiaohongshu tidak valid atau telah berubah. Detail: {e}")

        # 7. Transformasi dari data mentah ke model data bersih
        return self._transform_to_clean_data(note_detail_raw)

    def _transform_to_clean_data(self, note_data: Dict[str, Any]) -> XiaohongshuNoteData:
        """
        Mengubah dictionary data mentah dari API menjadi model Pydantic yang bersih.
        """
        interact_info = note_data.get('interactInfo', {})
        
        author_info = AuthorInfo(
            user_id=note_data['user']['userId'],
            nickname=note_data['user']['nickname'],
            avatar_url=note_data['user']['avatar']
        )
        
        stats_info = StatisticsInfo(
            likes=interact_info.get('likedCount', 0),
            favorites=interact_info.get('collectedCount', 0),
            comments=interact_info.get('commentCount', 0),
            shares=interact_info.get('shareCount', 0)
        )
        
        video_info = None
        image_info_list = []
        
        note_type = note_data.get('type')
        if note_type == 'video':
            video_raw = note_data.get('video', {})
            streams = []
            # 'stream' bisa kosong, jadi perlu pengecekan
            if video_raw.get('stream'):
                for key, stream_list in video_raw['stream'].items():
                    if key.startswith('h264'): # Hanya ambil stream h264
                        for stream in stream_list:
                            streams.append(VideoStreamInfo(
                                format=stream.get('format', ''),
                                url=stream.get('masterUrl', ''),
                                height=stream.get('height', 0),
                                width=stream.get('width', 0)
                            ))
            
            video_info = VideoDetail(
                cover_url=video_raw.get('media', {}).get('cover', {}).get('urlDefault', ''),
                duration_ms=video_raw.get('media', {}).get('videoDuration', 0),
                streams=streams
            )
        else: # 'normal' atau tipe gambar lainnya
            for img in note_data.get('imageList', []):
                image_info_list.append(ImageInfo(
                    url=img.get('urlDefault', ''),
                    width=img.get('width', 0),
                    height=img.get('height', 0)
                ))

        return XiaohongshuNoteData(
            note_id=note_data['noteId'],
            note_type=note_type,
            title=note_data['title'],
            description=note_data['desc'],
            created_at_timestamp=int(note_data['time'] / 1000), # Konversi ms ke detik
            author=author_info,
            statistics=stats_info,
            images=image_info_list if image_info_list else None,
            video=video_info
        )
