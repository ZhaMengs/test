import re
import hashlib
from typing import Optional
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Regex untuk mengekstrak Note ID dari berbagai format URL Xiaohongshu
NOTE_ID_PATTERN = re.compile(r"/(?:explore|discovery/item)/([a-f0-9]{24})")

class XSignManager:
    """
    Mengelola pembuatan signature `X-Sign` yang diperlukan untuk otentikasi
    permintaan ke API Xiaohongshu.
    """
    def __init__(self, salt: str):
        if not salt:
            raise ValueError("Salt untuk X-Sign tidak boleh kosong.")
        self.salt = salt

    def generate_xsign(self, api_path: str, data: Optional[str] = None) -> str:
        """
        Menghasilkan signature X-Sign.
        
        Algoritma umumnya adalah: md5(api_path + data_string + salt)
        Untuk GET request, data_string seringkali kosong.
        
        :param api_path: Path dari endpoint API (contoh: /api/sns/web/v1/feed).
        :param data: Payload data untuk request (biasanya untuk POST), dalam bentuk string.
        :return: String signature X-Sign.
        """
        # Gabungkan path, data (jika ada), dan salt
        base_string = api_path
        if data:
            base_string += data
        base_string += self.salt

        # Hitung MD5 hash
        signature = hashlib.md5(base_string.encode('utf-8')).hexdigest()
        
        # Tambahkan prefix "X" sesuai format
        return f"X{signature}"

async def extract_note_id(url: str) -> str:
    """
    Mengekstrak Note ID dari URL Xiaohongshu.
    Contoh URL: https://www.xiaohongshu.com/explore/65d8a9b3000000001e02q5r3
    
    :param url: URL postingan Xiaohongshu.
    :return: String Note ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    match = NOTE_ID_PATTERN.search(parsed_url.path)
    
    if match:
        return match.group(1)
    else:
        raise ContentNotFoundError(f"Tidak dapat mengekstrak Note ID dari URL: {url}")
