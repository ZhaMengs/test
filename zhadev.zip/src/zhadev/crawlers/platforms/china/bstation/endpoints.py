class BstationEndpoints:
    """
    Menyimpan endpoint API utama untuk Bstation (bilibili.tv)
    """
    API_DOMAIN: str = "https://api.bilibili.tv"

    SEASON_VIEW: str = f"{API_DOMAIN}/pgc/view/web/season"

    VIDEO_PLAYURL: str = f"{API_DOMAIN}/pgc/player/web/playurl"
