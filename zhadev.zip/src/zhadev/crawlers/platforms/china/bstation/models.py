from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================

# Model untuk endpoint /pgc/view/web/season
class EpisodeRaw(BaseModel):
    id: int
    aid: int
    bvid: str
    cid: int
    title: str
    long_title: str = Field(..., alias="longTitle")
    cover: str
    duration: int # dalam milidetik

class StatRaw(BaseModel):
    likes: int
    coins: int
    favorites: int
    views: int

class SeasonViewResultRaw(BaseModel):
    title: str
    cover: str
    season_id: int = Field(..., alias="seasonId")
    total: int # jumlah episode
    episodes: List[EpisodeRaw]
    stat: StatRaw

class BstationViewRawResponse(BaseModel):
    code: int
    message: str
    result: Optional[SeasonViewResultRaw] = None

# Model untuk endpoint /pgc/player/web/playurl
class StreamInfoRaw(BaseModel):
    id: int
    baseUrl: str
    codecs: str
    width: int
    height: int
    frameRate: str
    bandwidth: int

class DashRaw(BaseModel):
    video: Optional[List[StreamInfoRaw]] = None
    audio: Optional[List[StreamInfoRaw]] = None

class PlayUrlResultRaw(BaseModel):
    dash: Optional[DashRaw] = None

class BstationPlayUrlRawResponse(BaseModel):
    code: int
    message: str
    result: Optional[PlayUrlResultRaw] = None

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class StreamInfo(BaseModel):
    quality_id: int
    url: str
    codecs: str
    width: int
    height: int
    frame_rate: str
    bandwidth_kbps: int

class StatisticsInfo(BaseModel):
    views: int
    likes: int
    coins: int
    favorites: int

class BstationVideoData(BaseModel):
    """Output akhir yang komprehensif dari Bstation Crawler."""
    status: str = "success"
    platform: str = "bstation"
    season_id: int
    episode_id: int
    cid: int
    season_title: str
    episode_title: str
    cover_url: str
    duration_ms: int
    statistics: StatisticsInfo
    video_streams: List[StreamInfo]
    audio_streams: List[StreamInfo]
