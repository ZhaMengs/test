class WeiboEndpoints:
    """
    Menyimpan endpoint API utama untuk Weibo (versi Mobile Web).
    """
    API_DOMAIN: str = "https://m.weibo.cn"

    # Endpoint untuk mendapatkan detail lengkap sebuah postingan (status).
    # Menggunakan ID postingan (bisa numeric atau alphanumeric).
    STATUS_DETAIL: str = f"{API_DOMAIN}/statuses/show"
