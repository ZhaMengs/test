from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================

class UserRaw(BaseModel):
    id: int
    screen_name: str
    profile_image_url: str
    description: str

class ImageUrlSet(BaseModel):
    thumbnail_pic: Optional[str] = None
    bmiddle_pic: Optional[str] = None
    large_pic: Optional[str] = None
    original_pic: Optional[str] = None

class PicRaw(BaseModel):
    pid: str
    url: str
    size: str
    geo: Any
    large: ImageUrlSet

class VideoStreamRaw(BaseModel):
    url: Optional[str] = None
    quality_desc: Optional[str] = Field(None, alias="qualityDesc")

class PageInfoRaw(BaseModel):
    type: str
    page_pic: Optional[ImageUrlSet] = None
    media_info: Optional[Dict[str, Any]] = None
    urls: Optional[Dict[str, str]] = None # Format lama untuk stream
    slide_cover: Optional[Dict[str, List[VideoStreamRaw]]] = None # Format baru

class PostDataRaw(BaseModel):
    id: str # Alphanumeric ID
    mid: str # Numeric ID
    text: str
    created_at: str
    user: UserRaw
    reposts_count: int
    comments_count: int
    attitudes_count: int
    pics: Optional[List[PicRaw]] = None
    page_info: Optional[PageInfoRaw] = None

class WeiboAPIRawResponse(BaseModel):
    ok: int
    data: Optional[PostDataRaw] = None
    msg: Optional[str] = None

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class AuthorInfo(BaseModel):
    id: int
    username: str
    avatar_url: str
    description: str

class ImageInfo(BaseModel):
    id: str
    thumbnail_url: str
    medium_url: str
    large_url: str
    original_url: str

class VideoInfo(BaseModel):
    cover_url: str
    duration: float # dalam detik
    streams: Dict[str, str] # Contoh: {"720p": "url", "480p": "url"}

class StatisticsInfo(BaseModel):
    reposts: int
    comments: int
    likes: int

class WeiboPostData(BaseModel):
    """Output akhir yang komprehensif dari Weibo Crawler."""
    status: str = "success"
    platform: str = "weibo"
    id: str
    mid: str
    post_type: str # 'text', 'image', atau 'video'
    text: str
    created_at: str
    author: AuthorInfo
    statistics: StatisticsInfo
    images: Optional[List[ImageInfo]] = None
    video: Optional[VideoInfo] = None
