import os
import yaml
from typing import Dict, Any

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import BilibiliEndpoints
from .models import (
    BilibiliViewRawResponse, BilibiliPlayUrlRawResponse, BilibiliVideoData,
    AuthorInfo, StatisticsInfo, StreamInfo
)
from .utils import extract_video_id
from .wrid import WbiManager  # <-- IMPOR WbiManager

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class BilibiliCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Bilibili.
    Kini dengan dukungan signature w_rid untuk kompatibilitas API yang lebih luas.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['bilibili']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")

        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))
        
        # Inisialisasi WbiManager
        self.wbi_manager = WbiManager()

        if not self.headers.get("Cookie") or "SESSDATA" not in self.headers.get("Cookie", ""):
            print("PERINGATAN: Cookie SESSDATA tidak ditemukan di config.yaml. Kualitas stream mungkin terbatas.")

    async def get_video_data(self, url: str) -> BilibiliVideoData:
        """
        Metode utama untuk mengambil data video Bilibili dalam dua langkah.
        """
        bvid, aid = await extract_video_id(url)
        view_params = {"bvid": bvid} if bvid else {"aid": aid}

        # Panggil API /view (biasanya tidak memerlukan w_rid, tapi aman untuk menambahkannya)
        signed_view_params = self.wbi_manager.sign_params(view_params)
        
        try:
            view_response_json = await self.fetch_json(BilibiliEndpoints.VIDEO_VIEW, params=signed_view_params)
            view_data = BilibiliViewRawResponse.model_validate(view_response_json)
            if view_data.code != 0 or not view_data.data:
                raise ContentNotFoundError(f"API Bilibili (view) mengembalikan error: {view_data.message}")
            video_meta = view_data.data
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API Bilibili (view) berubah. Detail: {e}")

        cid = video_meta.pages[0].cid

        # Panggil API /playurl (endpoint ini lebih mungkin memerlukan w_rid di masa depan)
        playurl_params = {
            "bvid": bvid,
            "cid": cid,
            "fnval": 80
        }
        signed_playurl_params = self.wbi_manager.sign_params(playurl_params)
        
        try:
            playurl_response_json = await self.fetch_json(BilibiliEndpoints.VIDEO_PLAYURL, params=signed_playurl_params)
            playurl_data = BilibiliPlayUrlRawResponse.model_validate(playurl_response_json)
            if playurl_data.code != 0 or not playurl_data.data:
                raise ContentNotFoundError(f"API Bilibili (playurl) mengembalikan error: {playurl_data.message}")
            stream_meta = playurl_data.data
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API Bilibili (playurl) berubah. Detail: {e}")

        return self._transform_to_clean_data(video_meta, stream_meta, cid)

    def _transform_to_clean_data(self, video_meta: Any, stream_meta: Any, cid: int) -> BilibiliVideoData:
        # ... (Fungsi ini tidak berubah dari implementasi sebelumnya)
        author_info = AuthorInfo(
            mid=video_meta.owner.mid,
            name=video_meta.owner.name,
            avatar_url=video_meta.owner.face
        )
        stats_info = StatisticsInfo(
            views=video_meta.stat.view, danmaku=video_meta.stat.danmaku,
            comments=video_meta.stat.reply, favorites=video_meta.stat.favorite,
            coins=video_meta.stat.coin, shares=video_meta.stat.share,
            likes=video_meta.stat.like
        )
        video_streams, audio_streams = [], []
        if stream_meta.dash:
            if stream_meta.dash.video:
                for stream in stream_meta.dash.video:
                    video_streams.append(StreamInfo(
                        quality_id=stream.id, url=stream.base_url, codecs=stream.codecs,
                        width=stream.width, height=stream.height, frame_rate=stream.frame_rate,
                        bandwidth_kbps=int(stream.bandwidth / 1000)
                    ))
            if stream_meta.dash.audio:
                for stream in stream_meta.dash.audio:
                    audio_streams.append(StreamInfo(
                        quality_id=stream.id, url=stream.base_url, codecs=stream.codecs,
                        width=0, height=0, frame_rate="",
                        bandwidth_kbps=int(stream.bandwidth / 1000)
                    ))
        return BilibiliVideoData(
            bvid=video_meta.bvid, aid=video_meta.aid, cid=cid,
            title=video_meta.title, description=video_meta.desc,
            cover_url=video_meta.pic, published_at_timestamp=video_meta.pubdate,
            duration_seconds=video_meta.pages[0].duration,
            author=author_info, statistics=stats_info,
            video_streams=video_streams, audio_streams=audio_streams
        )
