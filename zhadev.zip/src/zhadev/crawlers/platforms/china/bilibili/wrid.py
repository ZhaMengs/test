import hashlib
import time
from functools import reduce
from typing import Dict

class WbiManager:
    """
    Mengelola dan menghasilkan signature w_rid untuk otentikasi permintaan WBI Bilibili.
    """
    # Kunci-kunci ini diekstrak dari JavaScript Bilibili.
    # Mereka digunakan dalam proses "mixing" untuk menghasilkan salt akhir.
    MIXIN_KEY_TABLE = [
        46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49,
        33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40,
        61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11,
        36, 20, 34, 44, 52
    ]

    def __init__(self):
        # Kunci WBI (imgKey dan subKey) ini biasanya didapat dari sebuah API,
        # namun nilai-nilai ini relatif statis dan dapat di-hardcode untuk stabilitas.
        self.img_key = "7cd084941338484aae1ad9425b84077c"
        self.sub_key = "4932caff0ff746e18d41de6a6097019a"
        self.salt = self.img_key + self.sub_key

    def _get_mixin_key(self) -> str:
        """
        Menghasilkan "salt" akhir dengan mengacak kunci WBI menggunakan tabel mixin.
        """
        return reduce(lambda s, i: s + self.salt[i], self.MIXIN_KEY_TABLE, "")[:32]

    def sign_params(self, params: Dict[str, any]) -> Dict[str, any]:
        """
        Menerima parameter, menambahkan wts, menghasilkan w_rid, dan mengembalikannya.
        
        :param params: Dictionary parameter permintaan asli.
        :return: Dictionary parameter yang telah ditambahkan wts dan w_rid.
        """
        signed_params = params.copy()
        salt = self._get_mixin_key()
        
        # 1. Tambahkan timestamp saat ini
        current_time = int(time.time())
        signed_params['wts'] = current_time
        
        # 2. Urutkan parameter berdasarkan kunci secara alfabetis
        sorted_params = sorted(signed_params.items())
        
        # 3. Buat query string dari parameter yang sudah diurutkan
        # Nilai-nilai yang "tidak diinginkan" seperti spasi atau karakter khusus dihapus
        query_parts = []
        for key, value in sorted_params:
            value_str = str(value)
            # Hapus karakter yang tidak valid sesuai dengan implementasi JS Bilibili
            cleaned_value = "".join(filter(lambda char: char not in "!'()*", value_str))
            query_parts.append(f"{key}={cleaned_value}")
        
        query_string = "&".join(query_parts)
        
        # 4. Gabungkan dengan salt dan hitung hash MD5
        hash_string = query_string + salt
        w_rid = hashlib.md5(hash_string.encode('utf-8')).hexdigest()
        
        # 5. Tambahkan w_rid ke dictionary parameter
        signed_params['w_rid'] = w_rid
        
        return signed_params
