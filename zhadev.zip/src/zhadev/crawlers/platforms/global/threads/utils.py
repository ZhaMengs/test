# zhadev/src/zhadev/crawlers/platforms/global/threads/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak "shortcode" dari URL postingan Threads
# Contoh: /@username/post/CqZ1Xy...
POST_SHORTCODE_PATTERN = re.compile(r"/post/([a-zA-Z0-9_-]+)")

async def extract_post_shortcode(url: str) -> str:
    """
    Mengekstrak shortcode dari URL postingan Threads.
    
    :param url: URL postingan Threads.
    :return: String shortcode.
    :raises ContentNotFoundError: Jika shortcode tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = POST_SHORTCODE_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak shortcode dari URL: {url}")