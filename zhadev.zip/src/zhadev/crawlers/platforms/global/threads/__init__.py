# zhadev/src/zhadev/crawlers/platforms/global/threads/__init__.py

from .crawler import ThreadsCrawler

__all__ = ["ThreadsCrawler"]