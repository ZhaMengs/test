# zhadev/src/zhadev/crawlers/platforms/global/threads/models.py

from pydantic import BaseModel, Field
from typing import List, Optional

# ==============================================================================
# Model-model ini dirancang untuk data bersih yang diekstrak dari
# blok JSON yang ter-embed di halaman Threads.
# ==============================================================================

class AuthorInfo(BaseModel):
    """Informasi kreator postingan."""
    id: str
    username: str
    profile_pic_url: str
    is_verified: bool

class MediaInfo(BaseModel):
    """Mewakili satu item media (gambar atau video) dalam sebuah post."""
    type: str  # 'image' atau 'video'
    display_url: str
    video_url: Optional[str] = None
    width: int
    height: int

class StatisticsInfo(BaseModel):
    """Statistik interaksi postingan."""
    like_count: int
    reply_count: int

class ThreadsPostData(BaseModel):
    """Output akhir yang komprehensif dari Threads Crawler."""
    status: str = "success"
    platform: str = "threads"
    id: str
    shortcode: str
    url: str
    caption: Optional[str] = None
    published_at_timestamp: int
    author: AuthorInfo
    media: List[MediaInfo] # Bisa berisi satu atau lebih item (carousel)
    statistics: StatisticsInfo