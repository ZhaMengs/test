# zhadev/src/zhadev/crawlers/platforms/global/threads/endpoints.py

class ThreadsEndpoints:
    """
    Menyimpan endpoint utama untuk Threads.
    """
    BASE_URL: str = "https://www.threads.net"