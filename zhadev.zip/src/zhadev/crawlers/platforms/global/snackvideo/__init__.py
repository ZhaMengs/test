# zhadev/src/zhadev/crawlers/platforms/global/snackvideo/__init__.py

from .crawler import SnackVideoCrawler

__all__ = ["SnackVideoCrawler"]