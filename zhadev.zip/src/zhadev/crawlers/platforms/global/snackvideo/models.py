# zhadev/src/zhadev/crawlers/platforms/global/snackvideo/models.py

from pydantic import BaseModel, Field
from typing import List, Optional

# ==============================================================================
# Model-model ini dirancang untuk mem-parsing data dari blok JSON __NEXT_DATA__.
# ==============================================================================

class AuthorInfo(BaseModel):
    """Informasi kreator video."""
    id: str
    name: str
    avatar_url: str

class VideoInfo(BaseModel):
    """Informasi media video."""
    height: int
    width: int
    duration_ms: int
    url_no_watermark: str
    cover_url: str

class MusicInfo(BaseModel):
    """Informasi musik yang digunakan."""
    id: str
    name: str
    author: str

class StatisticsInfo(BaseModel):
    """Statistik interaksi video."""
    view_count: int
    like_count: int
    comment_count: int
    share_count: int

class SnackVideoData(BaseModel):
    """Output akhir yang komprehensif dari SnackVideo Crawler."""
    status: str = "success"
    platform: str = "snackvideo"
    id: str
    caption: str
    author: AuthorInfo
    video: VideoInfo
    music: MusicInfo
    statistics: StatisticsInfo