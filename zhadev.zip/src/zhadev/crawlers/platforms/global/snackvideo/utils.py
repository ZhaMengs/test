# zhadev/src/zhadev/crawlers/platforms/global/snackvideo/utils.py

import re
import httpx
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk URL pendek seperti sck.io
SHORT_URL_HOST = "sck.io"

async def resolve_short_url(url: str) -> str:
    """
    Mengikuti redirect dari URL pendek (sck.io) untuk mendapatkan URL video penuh.
    Jika bukan URL pendek, kembalikan URL asli.
    
    :param url: URL video SnackVideo, bisa pendek atau panjang.
    :return: String URL video yang penuh dan final.
    :raises ContentNotFoundError: Jika terjadi error saat request.
    """
    parsed_url = urlparse(url)
    
    if parsed_url.hostname == SHORT_URL_HOST:
        try:
            async with httpx.AsyncClient(follow_redirects=True) as client:
                response = await client.head(url, timeout=10)
                # URL final setelah semua redirect
                return str(response.url)
        except httpx.RequestError as e:
            raise ContentNotFoundError(f"Gagal mengikuti redirect untuk URL pendek: {e}")
    
    # Jika bukan URL pendek, kembalikan apa adanya
    return url