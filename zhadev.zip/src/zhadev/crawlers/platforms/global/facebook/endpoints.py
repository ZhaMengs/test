# zhadev/src/zhadev/crawlers/platforms/global/facebook/endpoints.py

class FacebookEndpoints:
    """
    Menyimpan endpoint utama untuk Facebook.
    Kita akan menargetkan versi mobile dasar untuk HTML yang lebih mudah diparsing.
    """
    BASE_URL: str = "https://www.facebook.com"
    # mbasic seringkali menjadi target yang lebih baik untuk scraping
    MBASIC_URL: str = "https://mbasic.facebook.com"