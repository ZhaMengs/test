# zhadev/src/zhadev/crawlers/platforms/global/facebook/__init__.py

from .crawler import FacebookCrawler

__all__ = ["FacebookCrawler"]