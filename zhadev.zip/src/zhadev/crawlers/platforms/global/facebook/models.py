# zhadev/src/zhadev/crawlers/platforms/global/facebook/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================
# Karena kita mengandalkan scraping HTML, kita tidak membuat model Raw API,
# melainkan langsung ke model data bersih.

class AuthorInfo(BaseModel):
    id: Optional[str] = None
    name: str
    url: str

class StreamInfo(BaseModel):
    quality: str # Contoh: "HD", "SD"
    url: str

class StatisticsInfo(BaseModel):
    likes: Optional[int] = None
    comments: Optional[int] = None
    shares: Optional[int] = None

class FacebookVideoData(BaseModel):
    """Output akhir yang komprehensif dari Facebook Crawler."""
    status: str = "success"
    platform: str = "facebook"
    id: str
    url: str
    text_content: str
    published_at: Optional[str] = None
    author: AuthorInfo
    statistics: StatisticsInfo
    streams: List[StreamInfo]
    thumbnail_url: Optional[str] = None