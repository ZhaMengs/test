# zhadev/src/zhadev/crawlers/platforms/global/twitter/crawler.py

import os
import json
import yaml
from typing import Any, Dict, List

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import TwitterEndpoints
from .models import TwitterTweetData, AuthorInfo, MediaInfo, VideoVariant, StatisticsInfo
from .utils import extract_tweet_id

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class TwitterCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Twitter/X yang menargetkan GraphQL API internal.
    Wajib menggunakan cookie dan token autentikasi.
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['twitter']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        self.auth_token = config.get('auth_token')
        self.csrf_token = config.get('csrf_token')
        if not self.auth_token or "YOUR_AUTH_TOKEN_HERE" in self.auth_token:
            raise CrawlingError("`auth_token` wajib diisi di config.yaml untuk crawler Twitter.")
        if not self.csrf_token or "YOUR_CT0_CSRF_TOKEN_HERE" in self.csrf_token:
            raise CrawlingError("`csrf_token` (ct0) wajib diisi di config.yaml untuk crawler Twitter.")
            
        # Siapkan header dengan autentikasi
        headers = config.get('headers', {})
        headers['Cookie'] = f"auth_token={self.auth_token}; ct0={self.csrf_token}"
        headers['x-csrf-token'] = self.csrf_token
        
        super().__init__(headers=headers, proxies=config.get('proxies'))
        self.guest_token: Optional[str] = None

    async def _get_guest_token(self) -> str:
        """Mengambil guest_token yang diperlukan untuk header Authorization."""
        if self.guest_token:
            return self.guest_token
            
        try:
            response = await self.post_json(TwitterEndpoints.GUEST_TOKEN_API, headers={"Authorization": "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"})
            self.guest_token = response.get('guest_token')
            if not self.guest_token:
                raise CrawlingError("Gagal mendapatkan guest_token dari API.")
            print(f"Info: Guest token didapatkan: {self.guest_token[:10]}...")
            return self.guest_token
        except Exception as e:
            raise CrawlingError(f"Gagal dalam proses aktivasi guest token: {e}")

    async def get_tweet_data(self, url: str) -> TwitterTweetData:
        # 1. Dapatkan guest token dan siapkan header otorisasi final
        guest_token = await self._get_guest_token()
        self.headers['Authorization'] = f"Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
        self.headers['x-guest-token'] = guest_token

        # 2. Ekstrak ID Tweet dari URL
        tweet_id = await extract_tweet_id(url)
        
        # 3. Siapkan variabel dan fitur untuk query GraphQL
        variables = {
            "focalTweetId": tweet_id,
            "with_rux_injections": False,
            "includePromotedContent": True,
            "withCommunity": True,
            "withQuickPromoteEligibilityTweetFields": True,
            "withBirdwatchNotes": True,
            "withVoice": True,
            "withV2Timeline": True
        }
        features = {
            "rweb_lists_timeline_redesign_enabled": True, "responsive_web_graphql_exclude_directive_enabled": True,
            "verified_phone_label_enabled": False, "creator_subscriptions_tweet_preview_api_enabled": True,
            "responsive_web_graphql_timeline_navigation_enabled": True, "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
            "tweetypie_unmention_optimization_enabled": True, "responsive_web_edit_tweet_api_enabled": True,
            "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True, "view_counts_everywhere_api_enabled": True,
            "longform_notetweets_consumption_enabled": True, "responsive_web_twitter_article_tweet_consumption_enabled": False,
            "tweet_awards_web_tipping_enabled": False, "freedom_of_speech_not_reach_fetch_enabled": True,
            "standardized_nudges_misinfo": True, "tweet_with_visibility_results_prefer_gql_limited_action_policy_enabled": True,
            "longform_notetweets_rich_text_read_enabled": True, "longform_notetweets_inline_media_enabled": True,
            "responsive_web_media_download_video_enabled": False, "responsive_web_enhance_cards_enabled": False
        }
        params = {
            "variables": json.dumps(variables),
            "features": json.dumps(features)
        }
        
        try:
            # 4. Panggil GraphQL API
            response_json = await self.fetch_json(TwitterEndpoints.TWEET_DETAIL, params=params)
            
            # 5. Navigasi ke data tweet yang relevan
            entries = response_json.get('data', {}).get('threaded_conversation_with_injections_v2', {}).get('instructions', [{}])[0].get('entries', [])
            tweet_data_raw = None
            for entry in entries:
                if entry.get('entryId') == f"tweet-{tweet_id}":
                    tweet_data_raw = entry['content']['itemContent']['tweet_results']['result']
                    break
            
            if not tweet_data_raw:
                raise ContentNotFoundError(f"Data untuk Tweet ID {tweet_id} tidak ditemukan dalam respons API.")

            # Menangani berbagai kemungkinan format respons
            if tweet_data_raw.get("__typename") == "TweetWithVisibilityResults":
                 tweet_data_raw = tweet_data_raw.get("tweet")

        except (ValidationError, KeyError, IndexError) as e:
            raise ParsingError(f"Gagal mem-parsing atau menavigasi respons GraphQL. Error: {e}")

        # 6. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(tweet_data_raw, url)

    def _transform_to_clean_data(self, raw_data: Dict[str, Any], url: str) -> TwitterTweetData:
        legacy = raw_data.get('legacy', {})
        user_legacy = raw_data.get('core', {}).get('user_results', {}).get('result', {}).get('legacy', {})
        
        author_info = AuthorInfo(
            rest_id=user_legacy.get('id_str', ''),
            screen_name=user_legacy.get('screen_name', ''),
            name=user_legacy.get('name', ''),
            profile_image_url_https=user_legacy.get('profile_image_url_https', ''),
            is_blue_verified=user_legacy.get('is_blue_verified', False)
        )
        
        media_list: List[MediaInfo] = []
        if 'extended_entities' in legacy and 'media' in legacy['extended_entities']:
            for media_item in legacy['extended_entities']['media']:
                media_type = media_item.get('type')
                video_variants = []
                best_url = media_item.get('media_url_https', '')

                if media_type == 'video' or media_type == 'animated_gif':
                    variants = media_item.get('video_info', {}).get('variants', [])
                    best_variant = max([v for v in variants if 'bit_rate' in v], key=lambda v: v['bit_rate'], default=None)
                    if best_variant:
                        best_url = best_variant['url']
                    
                    for v in variants:
                        video_variants.append(VideoVariant.model_validate(v))

                media_list.append(MediaInfo(
                    type=media_type,
                    display_url=media_item.get('media_url_https', ''),
                    media_url=best_url,
                    video_variants=video_variants if video_variants else None
                ))
                
        stats_info = StatisticsInfo(
            reply_count=legacy.get('reply_count', 0),
            retweet_count=legacy.get('retweet_count', 0),
            like_count=legacy.get('favorite_count', 0),
            bookmark_count=legacy.get('bookmark_count', 0),
            view_count=int(raw_data.get('views', {}).get('count', 0))
        )

        return TwitterTweetData(
            id=legacy.get('id_str', ''),
            url=url,
            text=legacy.get('full_text', ''),
            created_at=legacy.get('created_at', ''),
            author=author_info,
            media=media_list,
            statistics=stats_info
        )