# zhadev/src/zhadev/crawlers/platforms/global/twitter/endpoints.py

class TwitterEndpoints:
    """
    Menyimpan endpoint utama untuk API internal Twitter/X.
    """
    API_BASE_URL: str = "https://api.twitter.com"
    GUEST_TOKEN_API: str = f"{API_BASE_URL}/1.1/guest/activate.json"
    
    # Base URL untuk semua panggilan GraphQL
    GRAPHQL_BASE_URL: str = f"{API_BASE_URL}/graphql"

    # Query ID spesifik untuk mengambil detail sebuah Tweet.
    # Nilai ini bisa berubah jika Twitter/X melakukan update besar.
    TWEET_DETAIL_QUERY_ID: str = "0hWvD_eA2pFp_xcV5p9E5A"
    
    # URL lengkap untuk endpoint detail Tweet
    TWEET_DETAIL: str = f"{GRAPHQL_BASE_URL}/{TWEET_DETAIL_QUERY_ID}/TweetDetail"