# zhadev/src/zhadev/crawlers/platforms/global/instagram/endpoints.py

class InstagramEndpoints:
    """
    Menyimpan endpoint utama untuk Instagram Web API.
    """
    BASE_URL: str = "https://www.instagram.com"
    
    # Semua pengambilan data modern dilakukan melalui endpoint GraphQL.
    GRAPHQL_API: str = f"{BASE_URL}/api/graphql"