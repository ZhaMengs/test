# zhadev/src/zhadev/crawlers/platforms/global/instagram/crawler.py

import os
import json
import yaml
from typing import Any, List

from pydantic import ValidationError
from ....crawlers.base_crawler import BaseCrawler
from ....crawlers.exceptions import CrawlingError, ParsingError, ContentNotFoundError
from .endpoints import InstagramEndpoints
from .models import InstagramAPIRawResponse, InstagramPostData, AuthorInfo, MediaItem
from .utils import extract_shortcode, GraphQLHashes

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.yaml')

class InstagramCrawler(BaseCrawler):
    """
    Crawler komprehensif untuk Instagram yang menargetkan GraphQL API.
    Wajib menggunakan cookie autentikasi (sessionid).
    """
    def __init__(self):
        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = yaml.safe_load()['instagram']
        except Exception as e:
            raise CrawlingError(f"Gagal memuat atau parsing config.yaml: {e}")
        
        self.cookie = config.get('cookie')
        if not self.cookie or "sessionid" not in self.cookie:
            raise CrawlingError("Cookie `sessionid` wajib ada di config.yaml untuk crawler Instagram.")
        
        config['headers']['Cookie'] = self.cookie
        super().__init__(headers=config.get('headers'), proxies=config.get('proxies'))

    async def get_post_data(self, url: str) -> InstagramPostData:
        """
        Metode utama untuk mengambil data postingan dari Instagram via GraphQL.
        """
        # 1. Ekstrak shortcode dari URL
        shortcode = await extract_shortcode(url)
        
        # 2. Siapkan variabel dan parameter untuk panggilan GraphQL
        variables = {"shortcode": shortcode}
        params = {
            "query_hash": GraphQLHashes.POST_DETAIL,
            "variables": json.dumps(variables)
        }
        
        try:
            # 3. Panggil GraphQL API
            response_json = await self.fetch_json(InstagramEndpoints.GRAPHQL_API, params=params)
            validated_response = InstagramAPIRawResponse.model_validate(response_json)

            if not validated_response.data or not validated_response.data.shortcode_media:
                raise ContentNotFoundError(f"API GraphQL Instagram tidak mengembalikan data untuk shortcode: {shortcode}. Postingan mungkin tidak ada atau akun bersifat privat.")
            
            post_raw_data = validated_response.data.shortcode_media
        except ValidationError as e:
            raise ParsingError(f"Struktur respons API GraphQL Instagram berubah. Detail: {e}")

        # 4. Transformasi data mentah ke model data bersih
        return self._transform_to_clean_data(post_raw_data)

    def _transform_to_clean_data(self, raw_data: Any) -> InstagramPostData:
        """
        Mengubah objek data mentah dari GraphQL menjadi model Pydantic yang bersih.
        """
        author_info = AuthorInfo(**raw_data.owner.model_dump())
        
        caption = ""
        if raw_data.edge_media_to_caption.edges:
            caption = raw_data.edge_media_to_caption.edges[0]['node']['text']

        media_items: List[MediaItem] = []
        # Cek apakah ini postingan carousel (album)
        if raw_data.edge_sidecar_to_children and raw_data.edge_sidecar_to_children.edges:
            for edge in raw_data.edge_sidecar_to_children.edges:
                node = edge['node']
                media_items.append(MediaItem(
                    type='video' if node['is_video'] else 'image',
                    display_url=node['display_url'],
                    video_url=node.get('video_url')
                ))
        # Jika bukan carousel, ini postingan tunggal
        else:
            media_items.append(MediaItem(
                type='video' if raw_data.is_video else 'image',
                display_url=raw_data.display_url,
                video_url=raw_data.video_url
            ))
            
        return InstagramPostData(
            id=raw_data.id,
            shortcode=raw_data.shortcode,
            caption=caption,
            created_at_timestamp=raw_data.taken_at_timestamp,
            author=author_info,
            media_items=media_items
        )