# zhadev/src/zhadev/crawlers/platforms/global/github/__init__.py

from .crawler import GitHubCrawler

__all__ = ["GitHubCrawler"]