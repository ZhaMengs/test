# zhadev/src/zhadev/crawlers/platforms/global/github/utils.py

import re
from urllib.parse import urlparse
from typing import Tuple

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak "owner/repo" dari berbagai format URL GitHub.
# Contoh: https://github.com/owner/repo, github.com/owner/repo.git
REPO_PATH_PATTERN = re.compile(r"^/?([^/]+)/([^/.]+)")

async def parse_repo_url(url: str) -> Tuple[str, str]:
    """
    Mem-parsing URL GitHub untuk mendapatkan nama pemilik (owner) dan repositori.
    
    :param url: URL repositori GitHub.
    :return: Tuple berisi (owner, repo).
    :raises ContentNotFoundError: Jika format URL tidak valid.
    """
    parsed_url = urlparse(url)
    match = REPO_PATH_PATTERN.search(parsed_url.path)
    
    if match:
        owner = match.group(1)
        repo = match.group(2)
        return owner, repo

    raise ContentNotFoundError(f"Format URL GitHub tidak valid: {url}")