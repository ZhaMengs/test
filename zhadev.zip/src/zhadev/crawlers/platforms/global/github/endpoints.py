# zhadev/src/zhadev/crawlers/platforms/global/github/endpoints.py

class GitHubEndpoints:
    """
    Menyimpan endpoint utama untuk API v3 GitHub.
    """
    API_BASE_URL: str = "https://api.github.com"

    # Endpoint untuk mendapatkan detail repositori.
    # Format: /repos/{owner}/{repo}
    REPO_DETAIL: str = "/repos/{owner}/{repo}"

    # Endpoint untuk mendapatkan rilis terbaru dari sebuah repositori.
    LATEST_RELEASE: str = "/repos/{owner}/{repo}/releases/latest"