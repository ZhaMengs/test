# zhadev/src/zhadev/crawlers/platforms/global/terabox/__init__.py

from .crawler import TeraboxCrawler

__all__ = ["TeraboxCrawler"]