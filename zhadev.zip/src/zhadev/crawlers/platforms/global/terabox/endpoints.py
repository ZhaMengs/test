# zhadev/src/zhadev/crawlers/platforms/global/terabox/endpoints.py

class TeraboxEndpoints:
    """
    Menyimpan endpoint utama untuk Terabox.
    """
    BASE_URL: str = "https://www.terabox.com"
    
    # API untuk mendapatkan daftar file dan metadata awal dari sebuah link share.
    SHARE_LIST: str = f"{BASE_URL}/share/list"

    # API untuk menghasilkan link unduhan langsung (dlink).
    # Endpoint ini tampaknya tidak digunakan lagi, logika baru ada di crawler.
    # Logika baru melibatkan pencarian parameter di dalam HTML.