from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================

class AuthorInfoRaw(BaseModel):
    id: str
    name: str
    avatar_url: str = Field(..., alias="avatarUrl")
    is_verified: bool = Field(..., alias="isVerified")

class VideoInfoRaw(BaseModel):
    cover_url: str = Field(..., alias="coverUrl")
    video_url: str = Field(..., alias="videoUrl")
    height: int
    width: int
    duration: int # dalam milidetik

class MusicInfoRaw(BaseModel):
    id: str
    title: str
    author: str

class TemplateDetailRaw(BaseModel):
    id: str
    title: str
    description: str
    author_info: AuthorInfoRaw = Field(..., alias="authorInfo")
    video_info: VideoInfoRaw = Field(..., alias="videoInfo")
    music_info: Optional[MusicInfoRaw] = Field(None, alias="musicInfo")
    usage_amount: int = Field(..., alias="usageAmount")
    like_count: int = Field(..., alias="likeCount")
    create_time: int = Field(..., alias="createTime") # timestamp detik

class CapcutAPIRawResponse(BaseModel):
    code: int
    message: str
    data: Optional[TemplateDetailRaw] = None

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class AuthorInfo(BaseModel):
    id: str
    name: str
    avatar_url: str
    is_verified: bool

class VideoInfo(BaseModel):
    cover_url: str
    video_url: str
    height: int
    width: int
    duration_ms: int

class MusicInfo(BaseModel):
    id: str
    title: str
    author: str

class StatisticsInfo(BaseModel):
    usage_count: int
    like_count: int

class CapcutTemplateData(BaseModel):
    """Output akhir yang komprehensif dari CapCut Crawler."""
    status: str = "success"
    platform: str = "capcut"
    id: str
    title: str
    description: str
    created_at_timestamp: int
    author: AuthorInfo
    video: VideoInfo
    music: Optional[MusicInfo] = None
    statistics: StatisticsInfo
