class CapcutEndpoints:
    """
    Menyimpan endpoint API utama untuk CapCut.
    """
    BASE_URL: str = "https://www.capcut.com"
    TEMPLATE_DETAIL: str = f"{BASE_URL}/api/v1/template_preview"
