# zhadev/src/zhadev/crawlers/platforms/global/pixeldrain/endpoints.py

class PixeldrainEndpoints:
    """
    Menyimpan endpoint utama untuk API v2 PixelDrain.
    """
    API_BASE_URL: str = "https://pixeldrain.com/api"

    # Endpoint untuk mendapatkan informasi/metadata sebuah file.
    # Format: /file/{id}/info
    FILE_INFO: str = f"{API_BASE_URL}/file/{{id}}/info"

    # Endpoint untuk mengunduh konten file secara langsung.
    # Format: /file/{id}
    FILE_DOWNLOAD: str = f"{API_BASE_URL}/file/{{id}}"