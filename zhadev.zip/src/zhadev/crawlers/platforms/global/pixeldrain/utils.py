# zhadev/src/zhadev/crawlers/platforms/global/pixeldrain/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak File ID dari berbagai format URL PixelDrain.
# Contoh: /u/abcde, /file/abcde
FILE_ID_PATTERN = re.compile(r"/(?:u|file)/([a-zA-Z0-9]+)")

async def extract_file_id(url: str) -> str:
    """
    Mengekstrak File ID dari URL PixelDrain.
    
    :param url: URL file PixelDrain.
    :return: String File ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = FILE_ID_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak File ID dari URL: {url}")