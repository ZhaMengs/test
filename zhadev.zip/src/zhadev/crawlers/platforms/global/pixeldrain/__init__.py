# zhadev/src/zhadev/crawlers/platforms/global/pixeldrain/__init__.py

from .crawler import PixeldrainCrawler

__all__ = ["PixeldrainCrawler"]