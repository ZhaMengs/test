# zhadev/src/zhadev/crawlers/platforms/global/tiktok/utils.py

import httpx
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

async def resolve_short_url(url: str) -> str:
    """
    Mengikuti redirect dari URL pendek (misal: vm.tiktok.com) untuk mendapatkan URL video penuh.
    Jika bukan URL pendek, kembalikan URL asli.
    
    :param url: URL video TikTok, bisa pendek atau panjang.
    :return: String URL video yang penuh dan final.
    :raises ContentNotFoundError: Jika terjadi error saat request.
    """
    if "vm.tiktok.com" in url or "vt.tiktok.com" in url:
        try:
            async with httpx.AsyncClient(follow_redirects=True) as client:
                response = await client.head(url, timeout=10)
                # URL final setelah semua redirect
                return str(response.url)
        except httpx.RequestError as e:
            raise ContentNotFoundError(f"Gagal mengikuti redirect untuk URL pendek: {e}")
    
    # Jika bukan URL pendek, kembalikan apa adanya
    return url