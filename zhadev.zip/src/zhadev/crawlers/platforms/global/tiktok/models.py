# zhadev/src/zhadev/crawlers/platforms/global/tiktok/models.py

from pydantic import BaseModel, Field
from typing import List, Optional

# ==============================================================================
# Model-model ini dirancang untuk data bersih yang diekstrak dari
# blok JSON __UNIVERSAL_DATA_FOR_REHYDRATION__.
# ==============================================================================

class AuthorInfo(BaseModel):
    """Informasi kreator video."""
    id: str
    unique_id: str = Field(..., alias="uniqueId")
    nickname: str
    avatar_url: str

class VideoInfo(BaseModel):
    """Informasi media video, termasuk berbagai URL."""
    id: str
    height: int
    width: int
    duration: int # dalam detik
    cover_url: str
    play_url_no_watermark: str
    download_url_watermarked: str

class MusicInfo(BaseModel):
    """Informasi musik yang digunakan dalam video."""
    id: str
    title: str
    author_name: str = Field(..., alias="authorName")
    play_url: str
    cover_thumb_url: str

class StatisticsInfo(BaseModel):
    """Statistik interaksi video."""
    like_count: int = Field(..., alias="diggCount")
    share_count: int = Field(..., alias="shareCount")
    comment_count: int = Field(..., alias="commentCount")
    play_count: int = Field(..., alias="playCount")
    favorite_count: int = Field(..., alias="collectCount")

class TikTokVideoData(BaseModel):
    """Output akhir yang komprehensif dari TikTok Crawler."""
    status: str = "success"
    platform: str = "tiktok"
    id: str
    description: str
    created_at_timestamp: int
    author: AuthorInfo
    video: VideoInfo
    music: MusicInfo
    statistics: StatisticsInfo