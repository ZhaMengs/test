# zhadev/src/zhadev/crawlers/platforms/global/mediafire/__init__.py

from .crawler import MediafireCrawler

__all__ = ["MediafireCrawler"]