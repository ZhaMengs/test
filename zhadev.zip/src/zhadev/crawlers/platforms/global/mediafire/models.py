# zhadev/src/zhadev/crawlers/platforms/global/mediafire/models.py

from pydantic import BaseModel
from typing import Optional

class MediafireFileData(BaseModel):
    """
    Output akhir yang komprehensif dari MediaFire Crawler.
    Berisi metadata file dan link unduhan langsung.
    """
    status: str = "success"
    platform: str = "mediafire"
    file_name: str
    file_size: str
    uploaded_on: str
    direct_download_url: str