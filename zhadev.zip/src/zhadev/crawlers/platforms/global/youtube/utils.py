# zhadev/src/zhadev/crawlers/platforms/global/youtube/utils.py

import re
import httpx
from urllib.parse import urlparse, parse_qs
from typing import Optional

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak Video ID dari berbagai format URL YouTube
# Contoh: watch?v={ID}, youtu.be/{ID}, embed/{ID}
VIDEO_ID_PATTERNS = [
    re.compile(r"v=([a-zA-Z0-9_-]{11})"),
    re.compile(r"youtu\.be/([a-zA-Z0-9_-]{11})"),
    re.compile(r"embed/([a-zA-Z0-9_-]{11})"),
]

async def extract_video_id(url: str) -> str:
    """
    Mengekstrak Video ID dari URL YouTube, termasuk mengatasi URL pendek.
    
    :param url: URL video YouTube (bisa panjang atau pendek).
    :return: String Video ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    # Untuk URL pendek youtu.be, ikuti redirect untuk mendapatkan URL penuh
    if "youtu.be" in urlparse(url).hostname:
        try:
            async with httpx.AsyncClient(follow_redirects=True, timeout=10) as client:
                response = await client.head(url)
                url = str(response.url)
        except httpx.RequestError as e:
            raise ContentNotFoundError(f"Gagal mengikuti redirect untuk URL pendek: {e}")

    for pattern in VIDEO_ID_PATTERNS:
        match = pattern.search(url)
        if match:
            return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Video ID dari URL: {url}")

def parse_initial_data(html: str) -> Optional[Dict]:
    """
    Mengekstrak objek `ytInitialData` (JSON) dari HTML halaman YouTube.
    
    :param html: Konten HTML halaman YouTube.
    :return: Dictionary dari `ytInitialData` atau None jika tidak ditemukan.
    """
    # Cari pola `var ytInitialData = { ... };`
    match = re.search(r"var\s+ytInitialData\s*=\s*({.+?});", html)
    if match:
        try:
            # Hati-hati dengan JSON yang tidak sempurna di HTML
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass # Lanjutkan mencari pola lain atau return None
            
    # Pola lain jika `ytInitialData` ter-embed di tag script dengan id `scriptLink`
    # Ini mungkin tidak selalu ada atau relevan
    # soup = BeautifulSoup(html, 'html.parser')
    # script_tag = soup.find('script', id='scriptLink')
    # if script_tag and script_tag.string:
    #     try:
    #         return json.loads(script_tag.string)
    #     except json.JSONDecodeError:
    #         pass
            
    return None

def parse_player_response(html: str) -> Optional[Dict]:
    """
    Mengekstrak objek `ytplayer.config.args.player_response` dari HTML.
    Ini sering mengandung informasi streaming yang lebih detail.
    
    :param html: Konten HTML halaman YouTube.
    :return: Dictionary dari `player_response` atau None.
    """
    match = re.search(r"ytplayer\.config\.args\.player_response\s*=\s*({.+?});", html)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            pass
    return None