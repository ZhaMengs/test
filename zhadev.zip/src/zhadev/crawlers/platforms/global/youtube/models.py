# zhadev/src/zhadev/crawlers/platforms/global/youtube/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model-model ini dirancang untuk mem-parsing data dari blok JSON `ytInitialData`.
# ==============================================================================

class AuthorInfo(BaseModel):
    """Informasi kreator video."""
    id: str
    name: str
    channel_url: str
    avatar_url: Optional[str] = None

class ThumbnailInfo(BaseModel):
    """Informasi thumbnail video dalam berbagai resolusi."""
    url: str
    width: int
    height: int

class StreamFormat(BaseModel):
    """Informasi dasar untuk satu format streaming."""
    itag: int
    url: str
    mime_type: str = Field(..., alias="mimeType")
    quality_label: Optional[str] = Field(None, alias="qualityLabel")
    bitrate: Optional[int] = None
    audio_codec: Optional[str] = Field(None, alias="audioCodec")
    video_codec: Optional[str] = Field(None, alias="videoCodec")

class YouTubeVideoData(BaseModel):
    """Output akhir yang komprehensif dari YouTube Crawler."""
    status: str = "success"
    platform: str = "youtube"
    id: str
    title: str
    description: Optional[str] = None
    upload_date: str
    view_count: Optional[int] = None
    like_count: Optional[int] = None
    author: AuthorInfo
    thumbnails: List[ThumbnailInfo]
    # URL stream yang terekstrak, seringkali memerlukan dekripsi atau penggabungan.
    # Ini adalah daftar format individual (video tanpa audio, audio tanpa video).
    # Untuk mendapatkan file video yang bisa diputar, perlu menggabungkan stream ini.
    stream_formats: List[StreamFormat]