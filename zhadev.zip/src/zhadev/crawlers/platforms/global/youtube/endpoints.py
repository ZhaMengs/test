# zhadev/src/zhadev/crawlers/platforms/global/youtube/endpoints.py

class YouTubeEndpoints:
    """
    Menyimpan endpoint utama untuk YouTube.
    """
    BASE_URL: str = "https://www.youtube.com"
    WATCH_URL: str = f"{BASE_URL}/watch?v="