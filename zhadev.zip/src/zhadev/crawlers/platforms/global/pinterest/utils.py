# zhadev/src/zhadev/crawlers/platforms/global/pinterest/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak ID Pin dari path URL.
# Contoh: /pin/8612871-34-2-10-1/
PIN_ID_PATTERN = re.compile(r"/pin/(\d+)/?")

async def extract_pin_id(url: str) -> str:
    """
    Mengekstrak Pin ID dari URL Pinterest.
    
    :param url: URL Pin Pinterest.
    :return: String Pin ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    parsed_url = urlparse(url)
    path = parsed_url.path
    
    match = PIN_ID_PATTERN.search(path)
    if match:
        return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak Pin ID dari URL: {url}")