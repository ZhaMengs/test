# zhadev/src/zhadev/crawlers/platforms/global/spotify/models.py

from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model-model ini secara ketat memetakan respons dari API resmi Spotify.
# ==============================================================================

class ArtistInfo(BaseModel):
    """Informasi ringkas tentang artis."""
    id: str
    name: str
    external_urls: Dict[str, str] = Field(..., alias="externalUrls")

class AlbumImage(BaseModel):
    """Informasi URL gambar album dalam berbagai ukuran."""
    height: int
    width: int
    url: str

class AlbumInfo(BaseModel):
    """Informasi tentang album."""
    id: str
    name: str
    album_type: str = Field(..., alias="albumType")
    images: List[AlbumImage]
    release_date: str = Field(..., alias="releaseDate")
    external_urls: Dict[str, str] = Field(..., alias="externalUrls")

class TrackInfo(BaseModel):
    """
    Output akhir yang komprehensif dari Spotify Crawler untuk sebuah lagu.
    """
    status: str = "success"
    platform: str = "spotify"
    id: str
    name: str
    artists: List[ArtistInfo]
    album: AlbumInfo
    duration_ms: int = Field(..., alias="durationMs")
    explicit: bool
    track_number: int = Field(..., alias="trackNumber")
    disc_number: int = Field(..., alias="discNumber")
    popularity: int
    preview_url: Optional[str] = Field(None, alias="previewUrl")
    external_urls: Dict[str, str] = Field(..., alias="externalUrls")