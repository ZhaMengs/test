# zhadev/src/zhadev/crawlers/platforms/global/gdrive/utils.py

import re
from urllib.parse import urlparse

from ....crawlers.exceptions import ContentNotFoundError

# Pola Regex untuk mengekstrak File ID dari berbagai format URL Google Drive
# Contoh: /file/d/{ID}/view, /uc?id={ID}, /open?id={ID}
FILE_ID_PATTERNS = [
    re.compile(r"/file/d/([a-zA-Z0-9_-]{28,})"),
    re.compile(r"uc\?id=([a-zA-Z0-9_-]{28,})"),
    re.compile(r"open\?id=([a-zA-Z0-9_-]{28,})")
]

async def extract_file_id(url: str) -> str:
    """
    Mengekstrak File ID dari URL Google Drive.
    
    :param url: URL file Google Drive.
    :return: String File ID.
    :raises ContentNotFoundError: Jika ID tidak dapat ditemukan.
    """
    for pattern in FILE_ID_PATTERNS:
        match = pattern.search(url)
        if match:
            return match.group(1)

    raise ContentNotFoundError(f"Tidak dapat mengekstrak File ID dari URL: {url}")