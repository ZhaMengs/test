# zhadev/src/zhadev/crawlers/platforms/global/gdrive/__init__.py

from .crawler import GDriveCrawler

__all__ = ["GDriveCrawler"]