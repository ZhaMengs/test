class DailymotionEndpoints:
    """
    Menyimpan endpoint API utama untuk Dailymotion.
    """
    BASE_URL: str = "https://www.dailymotion.com"

    # Dailymotion menggunakan satu endpoint GraphQL untuk hampir semua pengambilan data.
    GRAPHQL_API: str = f"{BASE_URL}/graphql"
