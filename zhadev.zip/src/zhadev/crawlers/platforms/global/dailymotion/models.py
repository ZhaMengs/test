from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

# ==============================================================================
# Model untuk Data Mentah dari API (Raw API Models)
# ==============================================================================
# GraphQL mengembalikan data dalam struktur `{"data": {...}}`.

class OwnerRaw(BaseModel):
    screenname: str
    url: str

class StreamRaw(BaseModel):
    type: str # contoh: "application/x-mpegURL" (HLS)
    url: str

class QualitiesRaw(BaseModel):
    auto: List[StreamRaw]

class VideoDetailsRaw(BaseModel):
    id: str
    title: str
    description: Optional[str] = None
    owner: OwnerRaw
    # Dailymotion tidak selalu menyediakan statistik secara publik via GraphQL
    views_total: Optional[int] = Field(None, alias="viewsTotal")
    # URL stream ada di dalam 'qualities'
    qualities: QualitiesRaw
    poster_url: str = Field(..., alias="posterURL")
    created_time: int = Field(..., alias="createdTime")

class GraphQLData(BaseModel):
    video: Optional[VideoDetailsRaw] = None

class DailymotionAPIRawResponse(BaseModel):
    data: Optional[GraphQLData] = None
    errors: Optional[List[Any]] = None

# ==============================================================================
# Model Data yang Telah Diproses (Cleaned Data Models)
# ==============================================================================

class AuthorInfo(BaseModel):
    username: str
    url: str

class StreamInfo(BaseModel):
    quality: str # Contoh: "auto"
    format: str # Contoh: "HLS" (m3u8)
    url: str

class StatisticsInfo(BaseModel):
    views: Optional[int] = None

class DailymotionVideoData(BaseModel):
    """Output akhir yang komprehensif dari Dailymotion Crawler."""
    status: str = "success"
    platform: str = "dailymotion"
    id: str
    title: str
    description: Optional[str] = None
    created_at_timestamp: int
    author: AuthorInfo
    cover_url: str
    statistics: StatisticsInfo
    streams: List[StreamInfo]
