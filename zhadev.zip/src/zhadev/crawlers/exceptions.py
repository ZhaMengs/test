# zhadev/src/zhadev/crawlers/exceptions.py

from typing import Optional

class CrawlerError(Exception):
    """Kelas dasar untuk semua exception yang terkait dengan crawler."""
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f'{self.__class__.__name__}: {self.message}'

class NetworkError(CrawlerError):
    """
    Terjadi ketika ada masalah jaringan (misalnya, timeout, DNS gagal).
    Membungkus httpx.RequestError.
    """
    pass

class APIError(CrawlerError):
    """
    Terjadi ketika API mengembalikan status code error (bukan 2xx).
    Membungkus httpx.HTTPStatusError.
    """
    def __init__(self, message: str, status_code: int, response_text: Optional[str] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_text = response_text

    def __str__(self):
        return f'{super().__str__()} (Status Code: {self.status_code})'

class AuthenticationError(APIError):
    """
    Sub-kelas dari APIError, spesifik untuk error 401 (Unauthorized) atau 403 (Forbidden).
    """
    pass

class ContentNotFoundError(APIError):
    """
    Sub-kelas dari APIError, spesifik untuk error 404 (Not Found) atau
    ketika konten yang diharapkan tidak ada di halaman.
    """
    pass

class ParsingError(CrawlerError):
    """
    Terjadi ketika ada kegagalan saat mem-parsing data (JSON tidak valid,
    elemen HTML tidak ditemukan).
    """
    pass